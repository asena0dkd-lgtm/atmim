export const colors = {
  primary: '#FF8A00',
  primarySoft: '#FFF3E2',
  teal: '#0E9384',
  tealSoft: '#E2F5F2',
  bg: '#F6F7F9',
  card: '#FFFFFF',
  text: '#1B1E28',
  sub: '#8A8F9E',
  danger: '#E5484D',
  dangerSoft: '#FDECEC',
  green: '#12B76A',
  border: '#ECEEF2',
};

export const card = {
  backgroundColor: colors.card,
  borderRadius: 16,
  padding: 14,
  marginBottom: 10,
  shadowColor: '#000',
  shadowOpacity: 0.05,
  shadowRadius: 8,
  shadowOffset: {width: 0, height: 2},
  elevation: 2,
};