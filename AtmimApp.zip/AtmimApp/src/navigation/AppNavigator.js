import React from 'react';
import {Text} from 'react-native';
import {NavigationContainer, DefaultTheme} from '@react-navigation/native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {colors} from '../theme/theme';
import TasksScreen from '../screens/TasksScreen';
import NotesScreen from '../screens/NotesScreen';
import RoomsScreen from '../screens/RoomsScreen';
import SettingsScreen from '../screens/SettingsScreen';
import AddTaskScreen from '../screens/AddTaskScreen';
import TaskDetailScreen from '../screens/TaskDetailScreen';
import NoteEditorScreen from '../screens/NoteEditorScreen';
import RoomCanvasScreen from '../screens/RoomCanvasScreen';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const ICONS = {tasks: '🏠', notes: '📝', rooms: '🎨', settings: '⚙️'};

function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={({route}) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.sub,
        tabBarStyle: {backgroundColor: colors.card, borderTopColor: colors.border, height: 60, paddingBottom: 6},
        tabBarLabelStyle: {fontSize: 12, fontWeight: '700'},
        tabBarIcon: ({focused}) => (
          <Text style={{fontSize: 20, opacity: focused ? 1 : 0.35}}>{ICONS[route.name]}</Text>
        ),
      })}>
      <Tab.Screen name="tasks" component={TasksScreen} options={{title: 'المهام'}} />
      <Tab.Screen name="notes" component={NotesScreen} options={{title: 'الملاحظات'}} />
      <Tab.Screen name="rooms" component={RoomsScreen} options={{title: 'الغرف'}} />
      <Tab.Screen name="settings" component={SettingsScreen} options={{title: 'المزيد'}} />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  const theme = {...DefaultTheme, colors: {...DefaultTheme.colors, background: colors.bg}};
  return (
    <NavigationContainer theme={theme}>
      <Stack.Navigator screenOptions={{headerShown: false}}>
        <Stack.Screen name="main" component={Tabs} />
        <Stack.Screen name="addTask" component={AddTaskScreen} />
        <Stack.Screen name="taskDetail" component={TaskDetailScreen} />
        <Stack.Screen name="noteEditor" component={NoteEditorScreen} />
        <Stack.Screen name="roomCanvas" component={RoomCanvasScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}