const AR = '٠١٢٣٤٥٦٧٨٩';
export const toAr = s => String(s).replace(/\d/g, d => AR[d]);

export const uid = () =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

const p2 = n => String(n).padStart(2, '0');

export const fmtTime = ts => {
  const d = new Date(ts);
  return `${p2(d.getHours())}:${p2(d.getMinutes())}`;
};

export const fmtDate = ts => {
  const d = new Date(ts);
  return `${d.getFullYear}/${p2(d.getMonth() + 1)}/${p2(d.getDate())}`;
};

export const fmtRemain = ms => {
  if (ms < 0) ms = 0;
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return h > 0 ? `${p2(h)}:${p2(m)}:${p2(sec)}` : `${p2(m)}:${p2(sec)}`;
};