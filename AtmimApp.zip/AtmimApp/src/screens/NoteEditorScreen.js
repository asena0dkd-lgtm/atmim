import React, {useMemo, useRef, useState} from 'react';
import {View, Text, TextInput, StyleSheet, TouchableOpacity, ScrollView,
  Modal, Share, Alert} from 'react-native';
import Clipboard from '@react-native-clipboard/clipboard';
import {useApp} from '../context/AppContext';
import Sketch, {pts2str} from '../components/Sketch';
import {colors} from '../theme/theme';
import {uid} from '../utils/helpers';
import Svg, {Polyline} from 'react-native-svg';

const PALETTE = ['#1B1E28', '#E5484D', '#FF8A00', '#0E9384', '#3E63DD'];
const TBtn = ({label, on, onPress}) => (
  <TouchableOpacity style={[st.tool, on && st.toolOn]} onPress={onPress}>
    <Text style={[st.toolTxt, on && {color: '#fff'}]}>{label}</Text>
  </TouchableOpacity>
);

export default function NoteEditorScreen({route, navigation}) {
  const {notes, updateNote} = useApp();
  const note = notes.find(n => n.id === route.params.id);
  const [activeId, setActiveId] = useState(null);
  const [drawOn, setDrawOn] = useState(false);
  const [pen, setPen] = useState('#E5484D');
  const [searchOn, setSearchOn] = useState(false);
  const [q, setQ] = useState('');
  const [rep, setRep] = useState('');
  const [snipOn, setSnipOn] = useState(false);
  const [snipTxt, setSnipTxt] = useState('');
  const [tblOn, setTblOn] = useState(false);
  const [tRows, setTRows] = useState('3');
  const [tCols, setTCols] = useState('3');
  const scrollRef = useRef();
  const yRef = useRef(0);
  if (!note) return null;

  const upd = patch => updateNote(note.id, patch);
  const updBlock = (id, patch) =>
    upd({blocks: note.blocks.map(b => (b.id === id ? {...b, ...patch} : b))});
  const active = note.blocks.find(b => b.id === activeId && b.type === 'line');

  const addLine = checkbox =>
    upd({blocks: [...note.blocks, {id: uid(), type: 'line', text: '', checkbox: !!checkbox, checked: false}]});

  const insertSnippet = s => {
    if (!active) return Alert.alert('أزرار النص', 'حدّد سطراً أولاً ثم اضغط الزر');
    updBlock(active.id, {text: active.text + s});
  };

  const addTable = () => {
    const r = Math.max(1, parseInt(tRows) || 1), c = Math.max(1, parseInt(tCols) || 1);
    upd({blocks: [...note.blocks, {id: uid(), type: 'table', rows: r, cols: c, cells: {}}]});
    setTblOn(false);
  };
  const updCell = (bid, k, v) =>
    upd({blocks: note.blocks.map(b => (b.id === bid ? {...b, cells: {...b.cells, [k]: v}} : b))});

  // ----- البحث مع السياق (كلمتان قبل وبعد) -----
  const results = useMemo(() => {
    if (!q) return [];
    const out = [];
    note.blocks.forEach(b => {
      if (b.type !== 'line' || !b.text) return;
      let i = 0;
      while (true) {
        i = b.text.indexOf(q, i);
        if (i < 0) break;
        const before = b.text.slice(Math.max(0, i - 15), i);
        const after = b.text.slice(i + q.length, i + q.length + 15);
        out.push({blockId: b.id, index: i, ctx: `…${before}【${q}】${after}…`});
        i += q.length;
      }
    });
    return out;
  }, [q, note.blocks]);

  const replaceAt = (r, withTxt) => {
    const b = note.blocks.find(x => x.id === r.blockId);
    updBlock(b.id, {text: b.text.slice(0, r.index) + withTxt + b.text.slice(r.index + q.length)});
  };
  const replaceAll = withTxt =>
    upd({blocks: note.blocks.map(b => b.type === 'line'
      ? {...b, text: b.text.split(q).join(withTxt)} : b)});

  // ----- التصدير -----
  const toMD = () => `# ${note.title}\n\n` + note.blocks.map(b =>
    b.type === 'table'
      ? Array.from({length: b.rows}).map((_, r) =>
          '| ' + Array.from({length: b.cols}).map((_, c) => b.cells[`${r}_${c}`] || ' ').join(' | ') + ' |').join('\n')
      : `${b.checkbox ? `- [${b.checked ? 'x' : ' '}] ` : ''}${b.bold ? '**' + b.text + '**' : b.text}`
  ).join('\n');
  const toHTML = () =>
    `<h1 dir="rtl">${note.title}</h1>` + note.blocks.map(b =>
      b.type === 'table'
        ? '<table border="1" dir="rtl">' + Array.from({length: b.rows}).map((_, r) =>
            '<tr>' + Array.from({length: b.cols}).map((_, c) =>
              `<td>${b.cells[`${r}_${c}`] || ''}</td>`).join('') + '</tr>').join('') + '</table>'
        : `<p dir="rtl">${b.checked ? '<s>' : ''}${b.text}${b.checked ? '</s>' : ''}</p>`
    ).join('');

  const exportAs = async kind => {
    const txt = kind === 'html' ? toHTML() : toMD();
    await Share.share({message: txt, title: `${note.title}.${kind}`});
  };

  const deco = b =>
    [b.underline && 'underline', (b.strike || b.checked) && 'line-through']
      .filter(Boolean).join(' ') || 'none';

  return (
    <View style={st.screen}>
      {/* الشريط العلوي */}
      <View style={st.topBar}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Text style={st.back}>→</Text></TouchableOpacity>
        <TextInput style={st.titleIn} value={note.title}
          onChangeText={t => upd({title: t})} placeholder="عنوان الملاحظة" placeholderTextColor={colors.sub} />
        <TouchableOpacity onPress={() => setSearchOn(true)}><Text style={st.topIco}>🔍</Text></TouchableOpacity>
      </View>

      {/* شريط الأدوات */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={st.tools}
        contentContainerStyle={{gap: 6, paddingHorizontal: 10, alignItems: 'center'}}>
        <TBtn label="B" on={!!active?.bold} onPress={() => active && updBlock(active.id, {bold: !active.bold})} />
        <TBtn label="U̲" on={!!active?.underline} onPress={() => active && updBlock(active.id, {underline: !active.underline})} />
        <TBtn label="S̶" on={!!active?.strike} onPress={() => active && updBlock(active.id, {strike: !active.strike})} />
        {PALETTE.map(c => (
          <TouchableOpacity key={c} style={[st.colorDot, {backgroundColor: c},
            active?.color === c && st.colorOn]}
            onPress={() => active && updBlock(active.id, {color: c})} />
        ))}
        <TBtn label="☑ مربع" on={false} onPress={() => addLine(true)} />
        <TBtn label="＋ سطر" on={false} onPress={() => addLine(false)} />
        <TBtn label="▦ جدول" on={false} onPress={() => setTblOn(true)} />
        <TBtn label="🔘 زر نص" on={false} onPress={() => setSnipOn(true)} />
        <TBtn label={drawOn ? '✓ إنهاء الرسم' : '✏️ رسم'} on={drawOn} onPress={() => setDrawOn(!drawOn)} />
        {drawOn && <TBtn label="🧹 مسح" on={false} onPress={() => upd({drawings: []})} />}
        <TBtn label="📍 واي بوينت" on={false} onPress={() => {upd({waypoint: yRef.current}); Alert.alert('📍', 'تم حفظ نقطة العودة');}} />
        <TBtn label="MD" on={false} onPress={() => exportAs('md')} />
        <TBtn label="HTML" on={false} onPress={() => exportAs('html')} />
        <TBtn label="📋 نسخ" on={false} onPress={() => {Clipboard.setString(toMD()); Alert.alert('تم النسخ ✓');}} />
      </ScrollView>

      {/* أزرار النصوص الجاهزة */}
      {!!note.snippets?.length && (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={st.snips}
          contentContainerStyle={{gap: 6, paddingHorizontal: 10, alignItems: 'center'}}>
          {note.snippets.map((s, i) => (
            <TouchableOpacity key={i} style={st.snip} onPress={() => insertSnippet(s)}
              onLongPress={() => upd({snippets: note.snippets.filter((_, x) => x !== i)})}>
              <Text style={st.snipTxt}>{s}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}

      {/* ألوان القلم أثناء الرسم */}
      {drawOn && (
        <View style={st.penRow}>
          {PALETTE.map(c => (
            <TouchableOpacity key={c} style={[st.colorDot, {backgroundColor: c}, pen === c && st.colorOn]}
              onPress={() => setPen(c)} />
          ))}
        </View>
      )}

      {/* المحتوى */}
      <View style={{flex: 1}}>
        <ScrollView ref={scrollRef} scrollEnabled={!drawOn}
          onScroll={e => (yRef.current = e.nativeEvent.contentOffset.y)}
          onLayout={() => note.waypoint && scrollRef.current?.scrollTo({y: note.waypoint, animated: false})}
          contentContainerStyle={{padding: 16, paddingBottom: 200}}>
          {note.blocks.map(b =>
            b.type === 'table' ? (
              <View key={b.id} style={st.table}>
                {Array.from({length: b.rows}).map((_, r) => (
                  <View key={r} style={{flexDirection: 'row-reverse'}}>
                    {Array.from({length: b.cols}).map((_, c) => {
                      const k = `${r}_${c}`;
                      return (
                        <TextInput key={k} style={st.cell} value={b.cells[k] || ''} multiline
                          onChangeText={v => updCell(b.id, k, v)} />
                      );
                    })}
                  </View>
                ))}
              </View>
            ) : (
              <View key={b.id} style={[st.lineRow, !drawOn && st.lineSep]}>
                {b.checkbox && (
                  <TouchableOpacity style={[st.cb, b.checked && st.cbOn]}
                    onPress={() => updBlock(b.id, {checked: !b.checked})}>
                    {b.checked && <Text style={{color: '#fff', fontSize: 12}}>✓</Text>}
                  </TouchableOpacity>
                )}
                <TextInput
                  style={[st.lineIn, {
                    fontWeight: b.bold ? '800' : '400',
                    textDecorationLine: deco(b),
                    color: b.checked ? colors.sub : b.color || colors.text,
                  }]}
                  value={b.text} multiline
                  onChangeText={t => updBlock(b.id, {text: t})}
                  onFocus={() => setActiveId(b.id)}
                  placeholder="اكتب هنا..." placeholderTextColor={colors.sub} />
                <TouchableOpacity onPress={() => upd({blocks: note.blocks.filter(x => x.id !== b.id)})}>
                  <Text style={{color: colors.border, fontSize: 12}}>✕</Text>
                </TouchableOpacity>
              </View>
            ),
          )}
        </ScrollView>

        {/* الرسم المحفوظ (خلفية) + طبقة الرسم */}
        <View style={StyleSheet.absoluteFill} pointerEvents="none">
          <Svg style={StyleSheet.absoluteFill}>
            {(note.drawings || []).map((p, i) => (
              <Polyline key={i} points={pts2str(p.pts)} stroke={p.color} strokeWidth={3}
                fill="none" strokeLinecap="round" />
            ))}
          </Svg>
        </View>
        {drawOn && (
          <View style={StyleSheet.absoluteFill}>
            <Sketch paths={[]} color={pen}
              onChange={newP => upd({drawings: [...(note.drawings || []), ...newP]})} />
          </View>
        )}
      </View>

      {/* نافذة البحث */}
      <Modal visible={searchOn} animationType="slide" transparent>
        <View style={st.modalBg}>
          <View style={st.modal}>
            <Text style={st.mTitle}>🔍 بحث في الملاحظة</Text>
            <TextInput style={st.mIn} value={q} onChangeText={setQ} placeholder="كلمة البحث..." placeholderTextColor={colors.sub} autoFocus />
            <TextInput style={st.mIn} value={rep} onChangeText={setRep} placeholder="نص الاستبدال (اختياري)..." placeholderTextColor={colors.sub} />
            {!!q && (
              <View style={st.mRow}>
                <TouchableOpacity style={st.mBtn} onPress={() => replaceAll(rep)}><Text style={st.mBtnTxt}>استبدال الكل</Text></TouchableOpacity>
                <TouchableOpacity style={[st.mBtn, {backgroundColor: colors.dangerSoft}]}
                  onPress={() => replaceAll('')}><Text style={[st.mBtnTxt, {color: colors.danger}]}>حذف الكل</Text></TouchableOpacity>
              </View>
            )}
            <ScrollView style={{maxHeight: 220}}>
              {results.map((r, i) => (
                <View key={i} style={st.resRow}>
                  <Text style={st.resCtx} numberOfLines={1}>{r.ctx}</Text>
                  <TouchableOpacity onPress={() => replaceAt(r, rep)}><Text style={{color: colors.teal, fontWeight: '800'}}>تعديل</Text></TouchableOpacity>
                  <TouchableOpacity onPress={() => replaceAt(r, '')}><Text style={{color: colors.danger, fontWeight: '800'}}>حذف</Text></TouchableOpacity>
                </View>
              ))}
              {!!q && !results.length && <Text style={{color: colors.sub, textAlign: 'center'}}>لا نتائج</Text>}
            </ScrollView>
            <TouchableOpacity style={st.mClose} onPress={() => setSearchOn(false)}><Text style={{color: '#fff', fontWeight: '900'}}>إغلاق</Text></TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* نافذة زر نص جديد */}
      <Modal visible={snipOn} transparent animationType="fade">
        <View style={st.modalBg}>
          <View style={st.modal}>
            <Text style={st.mTitle}>🔘 زر نص سريع (إيموجي / كلمة طويلة)</Text>
            <TextInput style={st.mIn} value={snipTxt} onChangeText={setSnipTxt} placeholder="مثال: 🤣 أو كلمة إنجليزية صعبة" placeholderTextColor={colors.sub} />
            <TouchableOpacity style={st.mClose} onPress={() => {
              if (snipTxt.trim()) upd({snippets: [...(note.snippets || []), snipTxt.trim()]});
              setSnipTxt(''); setSnipOn(false);
            }}><Text style={{color: '#fff', fontWeight: '900'}}>إضافة الزر</Text></TouchableOpacity>
            <Text style={{color: colors.sub, fontSize: 11, marginTop: 8, textAlign: 'center'}}>اضغط مطولاً على أي زر لحذفه</Text>
          </View>
        </View>
      </Modal>

      {/* نافذة جدول جديد */}
      <Modal visible={tblOn} transparent animationType="fade">
        <View style={st.modalBg}>
          <View style={st.modal}>
            <Text style={st.mTitle}>▦ جدول جديد (يكبر تلقائياً مع النص)</Text>
            <View style={{flexDirection: 'row-reverse', gap: 10}}>
              <TextInput style={[st.mIn, {flex: 1}]} value={tRows} onChangeText={setTRows} keyboardType="numeric" placeholder="صفوف" />
              <TextInput style={[st.mIn, {flex: 1}]} value={tCols} onChangeText={setTCols} keyboardType="numeric" placeholder="أعمدة" />
            </View>
            <TouchableOpacity style={st.mClose} onPress={addTable}><Text style={{color: '#fff', fontWeight: '900'}}>إنشاء الجدول</Text></TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const st = StyleSheet.create({
  screen: {flex: 1, backgroundColor: colors.bg},
  topBar: {flexDirection: 'row', alignItems: 'center', backgroundColor: colors.card,
    padding: 12, gap: 10, borderBottomWidth: 1, borderColor: colors.border},
  back: {fontSize: 22, color: colors.sub},
  topIco: {fontSize: 18},
  titleIn: {flex: 1, fontSize: 16, fontWeight: '900', color: colors.text, textAlign: 'right'},
  tools: {backgroundColor: colors.card, maxHeight: 48, borderBottomWidth: 1, borderColor: colors.border},
  tool: {paddingHorizontal: 12, paddingVertical: 7, borderRadius: 10, backgroundColor: colors.bg},
  toolOn: {backgroundColor: colors.primary},
  toolTxt: {fontWeight: '800', color: colors.text, fontSize: 13},
  colorDot: {width: 24, height: 24, borderRadius: 12, borderWidth: 2, borderColor: '#fff'},
  colorOn: {borderColor: colors.primary, transform: [{scale: 1.15}]},
  snips: {maxHeight: 44, backgroundColor: colors.tealSoft},
  snip: {backgroundColor: '#fff', borderRadius: 16, paddingHorizontal: 14, paddingVertical: 6,
    borderWidth: 1, borderColor: colors.teal},
  snipTxt: {color: colors.teal, fontWeight: '800'},
  penRow: {flexDirection: 'row-reverse', gap: 10, padding: 8, backgroundColor: colors.card},
  lineRow: {flexDirection: 'row-reverse', alignItems: 'flex-start', gap: 8, paddingVertical: 4},
  lineSep: {borderBottomWidth: 0.5, borderColor: colors.border},
  lineIn: {flex: 1, fontSize: 15, color: colors.text, textAlign: 'right', padding: 2, lineHeight: 24},
  cb: {width: 20, height: 20, borderRadius: 5, borderWidth: 2, borderColor: colors.teal,
    alignItems: 'center', justifyContent: 'center', marginTop: 4},
  cbOn: {backgroundColor: colors.teal},
  table: {borderWidth: 1, borderColor: colors.border, borderRadius: 8, overflow: 'hidden', marginVertical: 8},
  cell: {flex: 1, borderWidth: 0.5, borderColor: colors.border, padding: 8, minHeight: 38,
    textAlign: 'right', color: colors.text, fontSize: 13},
  modalBg: {flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', padding: 20},
  modal: {backgroundColor: '#fff', borderRadius: 20, padding: 18},
  mTitle: {fontWeight: '900', color: colors.text, fontSize: 16, marginBottom: 10, textAlign: 'right'},
  mIn: {backgroundColor: colors.bg, borderRadius: 10, padding: 10, textAlign: 'right',
    color: colors.text, marginBottom: 8, fontWeight: '600'},
  mRow: {flexDirection: 'row-reverse', gap: 8, marginBottom: 8},
  mBtn: {backgroundColor: colors.tealSoft, borderRadius: 10, padding: 8, paddingHorizontal: 14},
  mBtnTxt: {color: colors.teal, fontWeight: '800', fontSize: 12},
  resRow: {flexDirection: 'row-reverse', alignItems: 'center', gap: 10, paddingVertical: 8,
    borderBottomWidth: 0.5, borderColor: colors.border},
  resCtx: {flex: 1, color: colors.text, fontSize: 12, textAlign: 'right'},
  mClose: {backgroundColor: colors.primary, borderRadius: 12, padding: 12, alignItems: 'center', marginTop: 10},
});