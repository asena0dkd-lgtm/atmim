import React, {useState} from 'react';
import {View, Text, TextInput, StyleSheet, TouchableOpacity, ScrollView, Alert} from 'react-native';
import {useApp} from '../context/AppContext';
import PomodoroBar from '../components/PomodoroBar';
import {colors, card} from '../theme/theme';
import {fmtDate, fmtTime, toAr, uid} from '../utils/helpers';

export default function TaskDetailScreen({route, navigation}) {
  const {tasks, notes, completeTask, failTask, cancelTask, deleteTask, updateTask} = useApp();
  const t = tasks.find(x => x.id === route.params.id);
  const [sub, setSub] = useState('');
  if (!t) return null;
  const note = notes.find(n => n.id === t.noteId);
  const running = !!t.pomodoroStartedAt && t.status === 'active';

  const toggleSub = id =>
    updateTask(t.id, {checklist: t.checklist.map(c => (c.id === id ? {...c, done: !c.done} : c))});
  const addSub = () => {
    if (!sub.trim()) return;
    updateTask(t.id, {checklist: [...(t.checklist || []), {id: uid(), text: sub.trim(), done: false}]});
    setSub('');
  };

  const Action = ({label, bg, onPress}) => (
    <TouchableOpacity style={[st.action, {backgroundColor: bg}]} onPress={onPress}>
      <Text style={st.actionTxt}>{label}</Text>
    </TouchableOpacity>
  );

  return (
    <ScrollView style={{flex: 1, backgroundColor: colors.bg}} contentContainerStyle={{padding: 16}}>
      <View style={st.topBar}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Text style={st.back}>→</Text></TouchableOpacity>
        <Text style={st.h} numberOfLines={1}>{t.title}</Text>
        <TouchableOpacity onPress={() =>
          Alert.alert('حذف', 'حذف المهمة نهائياً؟', [
            {text: 'إلغاء'}, {text: 'حذف', style: 'destructive',
              onPress: () => {deleteTask(t.id); navigation.goBack();}},
          ])}>
          <Text style={{fontSize: 18}}>🗑</Text>
        </TouchableOpacity>
      </View>

      <View style={card}>
        {!!t.description && <Text style={st.desc}>{t.description}</Text>}
        <View style={st.metaRow}>
          {!!t.scheduledAt && <Text style={st.meta}>📅 {fmtDate(t.scheduledAt)} · 🕐 {fmtTime(t.scheduledAt)}</Text>}
          {!!t.pomodoro && <Text style={st.meta}>⏳ {toAr(t.pomodoro)} دقيقة</Text>}
          {t.repeat !== 'none' && <Text style={st.meta}>🔁 {({daily: 'يومي', weekly: 'أسبوعي', monthly: 'شهري', yearly: 'سنوي', custom: `كل ${toAr(t.customDays)} يوم`})[t.repeat]}</Text>}
          {t.failCount > 0 && <Text style={[st.meta, {color: colors.danger}]}>✖ فشل {toAr(t.failCount)} مرات</Text>}
        </View>
        {running && (
          <PomodoroBar totalMinutes={t.pomodoro} startedAt={t.pomodoroStartedAt}
            onEnd={() => failTask(t.id)} />
        )}
        {!!t.pomodoro && !running && t.status === 'active' && (
          <TouchableOpacity style={st.startBtn}
            onPress={() => updateTask(t.id, {pomodoroStartedAt: Date.now()})}>
            <Text style={st.startTxt}>▶ ابدأ المؤقت الآن</Text>
          </TouchableOpacity>
        )}
      </View>

      <View style={card}>
        <Text style={st.sec}>✅ قائمة التحقق</Text>
        {(t.checklist || []).map(c => (
          <TouchableOpacity key={c.id} style={st.subRow} onPress={() => toggleSub(c.id)}>
            <View style={[st.subBox, c.done && st.subBoxOn]}>{c.done && <Text style={{color: '#fff', fontSize: 11}}>✓</Text>}</View>
            <Text style={[st.subTxt, c.done && {textDecorationLine: 'line-through', color: colors.sub}]}>{c.text}</Text>
          </TouchableOpacity>
        ))}
        <View style={st.subAdd}>
          <TextInput style={st.subInput} value={sub} onChangeText={setSub} placeholder="أضف خطوة فرعية..." placeholderTextColor={colors.sub} />
          <TouchableOpacity onPress={addSub}><Text style={{color: colors.primary, fontWeight: '900'}}>＋</Text></TouchableOpacity>
        </View>
      </View>

      {!!note && (
        <TouchableOpacity style={[card, st.noteBtn]} onPress={() => navigation.navigate('noteEditor', {id: note.id})}>
          <Text style={st.noteTxt}>📝 فتح الملاحظة المرتبطة: {note.title}</Text>
        </TouchableOpacity>
      )}

      {!!t.attachments?.length && (
        <View style={card}>
          <Text style={st.sec}>📎 المرفقات</Text>
          {t.attachments.map(a => (
            <View key={a.id} style={st.attachChip}><Text style={st.meta}>📄 {a.name}</Text></View>
          ))}
        </View>
      )}

      {t.status === 'active' && (
        <View style={st.actions}>
          <Action label="✓ إنجاز" bg={colors.green} onPress={() => {completeTask(t.id); navigation.goBack();}} />
          <Action label="✖ فشل" bg={colors.danger} onPress={() => failTask(t.id)} />
          <Action label="⊘ إلغاء" bg={colors.sub} onPress={() => {cancelTask(t.id); navigation.goBack();}} />
        </View>
      )}
    </ScrollView>
  );
}

const st = StyleSheet.create({
  topBar: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12, gap: 8},
  back: {fontSize: 22, color: colors.sub},
  h: {fontSize: 19, fontWeight: '900', color: colors.text, flex: 1, textAlign: 'right'},
  desc: {color: colors.text, textAlign: 'right', lineHeight: 22, marginBottom: 8},
  metaRow: {gap: 6},
  meta: {color: colors.sub, fontWeight: '700', fontSize: 12, textAlign: 'right'},
  sec: {fontWeight: '900', color: colors.text, marginBottom: 8, textAlign: 'right'},
  startBtn: {marginTop: 10, backgroundColor: colors.primarySoft, borderRadius: 10, padding: 10, alignItems: 'center'},
  startTxt: {color: colors.primary, fontWeight: '900'},
  subRow: {flexDirection: 'row-reverse', alignItems: 'center', gap: 10, paddingVertical: 6},
  subBox: {width: 20, height: 20, borderRadius: 6, borderWidth: 2, borderColor: colors.border, alignItems: 'center', justifyContent: 'center'},
  subBoxOn: {backgroundColor: colors.teal, borderColor: colors.teal},
  subTxt: {color: colors.text, fontWeight: '600', flex: 1, textAlign: 'right'},
  subAdd: {flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 6},
  subInput: {flex: 1, backgroundColor: colors.bg, borderRadius: 10, padding: 8, textAlign: 'right', color: colors.text},
  noteBtn: {backgroundColor: colors.tealSoft},
  noteTxt: {color: colors.teal, fontWeight: '800', textAlign: 'right'},
  attachChip: {backgroundColor: colors.bg, borderRadius: 10, padding: 10, marginBottom: 6},
  actions: {flexDirection: 'row-reverse', gap: 10, marginTop: 6, marginBottom: 30},
  action: {flex: 1, borderRadius: 14, padding: 14, alignItems: 'center'},
  actionTxt: {color: '#fff', fontWeight: '900'},
});