import React, {useState} from 'react';
import {View, Text, TextInput, StyleSheet, TouchableOpacity, ScrollView, Switch, Alert} from 'react-native';
import {useApp} from '../context/AppContext';
import {colors, card} from '../theme/theme';
import {uid} from '../utils/helpers';

const Chip = ({label, on, onPress}) => (
  <TouchableOpacity style={[st.chip, on && st.chipOn]} onPress={onPress}>
    <Text style={[st.chipTxt, on && st.chipTxtOn]}>{label}</Text>
  </TouchableOpacity>
);

const Stepper = ({value, onChange, min = 0, max = 999, suffix = ''}) => (
  <View style={st.stepper}>
    <TouchableOpacity style={st.stBtn} onPress={() => onChange(Math.min(max, value + 1))}><Text style={st.stTxt}>＋</Text></TouchableOpacity>
    <Text style={st.stVal}>{value}{suffix}</Text>
    <TouchableOpacity style={st.stBtn} onPress={() => onChange(Math.max(min, value - 1))}><Text style={st.stTxt}>－</Text></TouchableOpacity>
  </View>
);

export default function AddTaskScreen({navigation}) {
  const {addTask, tasks, notes, cheers, taunts} = useApp();
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [advanced, setAdvanced] = useState(false);
  // التوقيت
  const [schedMode, setSchedMode] = useState('none'); // none|today|tomorrow|custom
  const [hour, setHour] = useState(10);
  const [minute, setMinute] = useState(0);
  const [daysAfter, setDaysAfter] = useState(1);
  // بومودو + تكرار
  const [pomodoro, setPomodoro] = useState(0);
  const [repeat, setRepeat] = useState('none');
  const [customDays, setCustomDays] = useState(2);
  // ربط مهمة
  const [linkId, setLinkId] = useState(null);
  const [linkOn, setLinkOn] = useState('done');
  const [afterFails, setAfterFails] = useState(2);
  // نصوص
  const [cheer, setCheer] = useState('');
  const [taunt, setTaunt] = useState('');
  // ملاحظة + مرفقات
  const [noteId, setNoteId] = useState(null);
  const [attachments, setAttachments] = useState([]);

  const linkable = tasks.filter(t => t.status === 'active' && !t.hidden);

  const pickAttachment = async () => {
    try {
      const DP = require('react-native-document-picker').default;
      const r = await DP.pickSingle({type: [DP.types.allFiles]});
      setAttachments(a => [...a, {id: uid(), name: r.name, uri: r.uri, type: r.type || 'file'}]);
    } catch (e) {
      if (!e?.message?.includes('cancel'))
        Alert.alert('مرفقات', 'ثبّت الحزمة: npm i react-native-document-picker');
    }
  };

  const save = () => {
    if (!title.trim()) return Alert.alert('تنبيه', 'اسم المهمة مطلوب فقط 🙂');
    let scheduledAt = null;
    if (schedMode !== 'none') {
      const d = new Date();
      if (schedMode === 'tomorrow') d.setDate(d.getDate() + 1);
      if (schedMode === 'custom') d.setDate(d.getDate() + daysAfter);
      d.setHours(hour, minute, 0, 0);
      scheduledAt = d.getTime();
    }
    addTask({
      title: title.trim(), description: desc, scheduledAt,
      pomodoro: pomodoro || null, repeat, customDays,
      cheer, taunt, noteId, attachments,
      linked: linkId ? [{taskId: linkId, on: linkOn, afterFails: linkOn === 'failCount' ? afterFails : null}] : [],
    });
    if (linkId) {
      // المهمة المرتبطة تُخفى حتى يتحقق الشرط — نخزن الربط في هذه المهمة (المصدر)
    }
    navigation.goBack();
  };

  return (
    <ScrollView style={st.screen} contentContainerStyle={{padding: 16, paddingBottom: 60}}>
      <View style={st.topBar}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Text style={st.back}>✕</Text></TouchableOpacity>
        <Text style={st.h}>مهمة جديدة</Text>
        <View style={{width: 24}} />
      </View>

      <View style={card}>
        <Text style={st.lbl}>اسم المهمة *</Text>
        <TextInput style={st.input} value={title} onChangeText={setTitle} placeholder="مثال: دراسة عربي" placeholderTextColor={colors.sub} />
        <Text style={st.lbl}>الوصف (اختياري)</Text>
        <TextInput style={[st.input, {height: 70}]} value={desc} onChangeText={setDesc} multiline placeholder="تفاصيل إضافية..." placeholderTextColor={colors.sub} />
      </View>

      <View style={[card, st.advRow]}>
        <Text style={st.advTitle}>⚙️ إعدادات إضافية (كلها اختيارية)</Text>
        <Switch value={advanced} onValueChange={setAdvanced} trackColor={{true: colors.primary}} />
      </View>

      {advanced && (
        <>
          <View style={card}>
            <Text style={st.lbl}>🕐 وقت البدء (يُرسل إشعار ويبدأ المؤقت)</Text>
            <View style={st.chipsRow}>
              <Chip label="بدون وقت" on={schedMode === 'none'} onPress={() => setSchedMode('none')} />
              <Chip label="اليوم" on={schedMode === 'today'} onPress={() => setSchedMode('today')} />
              <Chip label="غداً" on={schedMode === 'tomorrow'} onPress={() => setSchedMode('tomorrow')} />
              <Chip label="مخصص" on={schedMode === 'custom'} onPress={() => setSchedMode('custom')} />
            </View>
            {schedMode !== 'none' && (
              <View style={st.rowBetween}>
                <Stepper value={hour} onChange={setHour} max={23} suffix=" س" />
                <Stepper value={minute} onChange={setMinute} max={59} suffix=" د" />
                {schedMode === 'custom' && <Stepper value={daysAfter} onChange={setDaysAfter} min={1} suffix=" يوم" />}
              </View>
            )}
          </View>

          <View style={card}>
            <Text style={st.lbl}>⏳ مؤقت بومودو (بالدقائق — ٠ بدون)</Text>
            <Stepper value={pomodoro} onChange={v => setPomodoro(Math.max(0, v))} suffix=" دقيقة" />
          </View>

          <View style={card}>
            <Text style={st.lbl}>🔁 التكرار</Text>
            <View style={st.chipsRow}>
              {[['none', 'بدون'], ['daily', 'يومي'], ['weekly', 'أسبوعي'], ['monthly', 'شهري'], ['yearly', 'سنوي'], ['custom', 'مخصص']].map(([k, l]) => (
                <Chip key={k} label={l} on={repeat === k} onPress={() => setRepeat(k)} />
              ))}
            </View>
            {repeat === 'custom' && (
              <View style={{marginTop: 8}}>
                <Stepper value={customDays} onChange={v => setCustomDays(Math.max(1, v))} suffix=" يوم" />
              </View>
            )}
          </View>

          <View style={card}>
            <Text style={st.lbl}>🔗 ربط مهمة (تظهر عند شرط)</Text>
            {linkable.length === 0 && <Text style={st.hint}>لا مهام متاحة للربط حالياً</Text>}
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={st.chipsRow}>
                {linkable.map(t => (
                  <Chip key={t.id} label={t.title} on={linkId === t.id}
                    onPress={() => setLinkId(linkId === t.id ? null : t.id)} />
                ))}
              </View>
            </ScrollView>
            {!!linkId && (
              <>
                <Text style={[st.lbl, {marginTop: 8}]}>تظهر المهمة المرتبطة عند:</Text>
                <View style={st.chipsRow}>
                  <Chip label="إنجاز المهمة" on={linkOn === 'done'} onPress={() => setLinkOn('done')} />
                  <Chip label="فشل المهمة" on={linkOn === 'fail'} onPress={() => setLinkOn('fail')} />
                  <Chip label="إلغاء المهمة" on={linkOn === 'cancel'} onPress={() => setLinkOn('cancel')} />
                  <Chip label="بلوغ عدد فشل" on={linkOn === 'failCount'} onPress={() => setLinkOn('failCount')} />
                </View>
                {linkOn === 'failCount' && (
                  <View style={{marginTop: 8}}>
                    <Stepper value={afterFails} onChange={v => setAfterFails(Math.max(1, v))} suffix=" مرات" />
                  </View>
                )}
              </>
            )}
          </View>

          <View style={card}>
            <Text style={st.lbl}>🎉 نص التشجيع عند الإنجاز</Text>
            <TextInput style={st.input} value={cheer} onChangeText={setCheer} placeholder="مثال: ممتاز رحت عالجيم! اصبر ورح تركض ٢٠ كيلو" placeholderTextColor={colors.sub} />
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={st.chipsRow}>
                {cheers.map((c, i) => <Chip key={i} label={`جاهز ${i + 1}`} on={false} onPress={() => setCheer(c)} />)}
              </View>
            </ScrollView>
            <Text style={[st.lbl, {marginTop: 10}]}>😤 نص التهذيب عند الفشل</Text>
            <TextInput style={st.input} value={taunt} onChangeText={setTaunt} placeholder="مثال: ما رحت عالجيم اه؟ قوم تحرك!" placeholderTextColor={colors.sub} />
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={st.chipsRow}>
                {taunts.map((t, i) => <Chip key={i} label={`جاهز ${i + 1}`} on={false} onPress={() => setTaunt(t)} />)}
              </View>
            </ScrollView>
          </View>

          <View style={card}>
            <Text style={st.lbl}>📝 ربط بملاحظة (زر داخل إشعار/بطاقة المهمة)</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={st.chipsRow}>
                {notes.map(n => (
                  <Chip key={n.id} label={n.title} on={noteId === n.id}
                    onPress={() => setNoteId(noteId === n.id ? null : n.id)} />
                ))}
              </View>
            </ScrollView>
            <Text style={[st.lbl, {marginTop: 10}]}>📎 المرفقات</Text>
            <TouchableOpacity style={st.attachBtn} onPress={pickAttachment}>
              <Text style={st.attachTxt}>＋ إرفاق ملف / صورة / فيديو / صوت</Text>
            </TouchableOpacity>
            {attachments.map(a => (
              <View key={a.id} style={st.attachChip}>
                <Text style={st.attachName} numberOfLines={1}>📄 {a.name}</Text>
                <TouchableOpacity onPress={() => setAttachments(x => x.filter(y => y.id !== a.id))}>
                  <Text style={{color: colors.danger}}>🗑</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        </>
      )}

      <TouchableOpacity style={st.save} onPress={save}>
        <Text style={st.saveTxt}>حفظ المهمة ✓</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const st = StyleSheet.create({
  screen: {flex: 1, backgroundColor: colors.bg},
  topBar: {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14},
  back: {fontSize: 20, color: colors.sub, padding: 4},
  h: {fontSize: 20, fontWeight: '900', color: colors.text},
  lbl: {fontSize: 13, fontWeight: '800', color: colors.text, marginBottom: 6, textAlign: 'right'},
  input: {backgroundColor: colors.bg, borderRadius: 10, padding: 10, color: colors.text,
    textAlign: 'right', marginBottom: 10, fontWeight: '600'},
  advRow: {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'},
  advTitle: {fontWeight: '800', color: colors.text},
  chipsRow: {flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 8},
  chip: {backgroundColor: colors.bg, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 18,
    borderWidth: 1, borderColor: colors.border},
  chipOn: {backgroundColor: colors.primary, borderColor: colors.primary},
  chipTxt: {color: colors.sub, fontWeight: '700', fontSize: 12},
  chipTxtOn: {color: '#fff'},
  stepper: {flexDirection: 'row', alignItems: 'center', gap: 12, alignSelf: 'flex-end', marginTop: 6},
  stBtn: {width: 36, height: 36, borderRadius: 10, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center'},
  stTxt: {color: colors.primary, fontSize: 18, fontWeight: '900'},
  stVal: {fontWeight: '900', color: colors.text, fontSize: 15, minWidth: 70, textAlign: 'center'},
  rowBetween: {flexDirection: 'row-reverse', justifyContent: 'space-around', marginTop: 8},
  hint: {color: colors.sub, fontSize: 12, textAlign: 'right'},
  attachBtn: {borderWidth: 1, borderStyle: 'dashed', borderColor: colors.primary, borderRadius: 12,
    padding: 12, alignItems: 'center'},
  attachTxt: {color: colors.primary, fontWeight: '800'},
  attachChip: {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: colors.bg, borderRadius: 10, padding: 10, marginTop: 8},
  attachName: {color: colors.text, fontWeight: '600', flex: 1},
  save: {backgroundColor: colors.primary, borderRadius: 16, padding: 16, alignItems: 'center', marginTop: 8},
  saveTxt: {color: '#fff', fontWeight: '900', fontSize: 16},
});