import React, {useState} from 'react';
import {View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert} from 'react-native';
import {useApp} from '../context/AppContext';
import {colors, card} from '../theme/theme';

const FEATURES = [
  ['🖼️', 'لوحة Canvas', 'لتنظيم أفكارك بصرياً'],
  ['✨', 'تصميم عصري', 'واضح وأنيق'],
  ['⚡', 'إشعارات ثابتة', 'لإضافة سريعة'],
  ['✏️', 'إيماءات ذكية', 'لتنفيذ المهام بسرعة'],
  ['🔄', 'مزامنة بين الأجهزة', 'النسخ الاحتياطي'],
  ['🔒', 'خصوصية وأمان', 'كامل لبياناتك'],
  ['💡', 'ذكاء اصطناعي', 'يعزز إنتاجيتك'],
];

export default function SettingsScreen() {
  const {cheers, taunts, setCheers, setTaunts} = useApp();
  const [txt, setTxt] = useState('');
  const [kind, setKind] = useState('cheer');

  const add = () => {
    if (!txt.trim()) return;
    if (kind === 'cheer') setCheers([...cheers, txt.trim()]);
    else setTaunts([...taunts, txt.trim()]);
    setTxt('');
  };
  const list = kind === 'cheer' ? cheers : taunts;
  const setList = kind === 'cheer' ? setCheers : setTaunts;

  return (
    <ScrollView style={{flex: 1, backgroundColor: colors.bg}} contentContainerStyle={{padding: 16}}>
      <Text style={st.h}>⚙️ المزيد</Text>

      <View style={card}>
        <Text style={st.sec}>💬 نصوص التشجيع والتهذيب الجاهزة</Text>
        <Text style={st.hint}>استخدم {'{task}'} ليُستبدل باسم المهمة تلقائياً</Text>
        <View style={st.row}>
          <TouchableOpacity style={[st.chip, kind === 'cheer' && st.on]} onPress={() => setKind('cheer')}>
            <Text style={[st.chipTxt, kind === 'cheer' && {color: '#fff'}]}>🎉 تشجيع</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[st.chip, kind === 'taunt' && st.on]} onPress={() => setKind('taunt')}>
            <Text style={[st.chipTxt, kind === 'taunt' && {color: '#fff'}]}>😤 تهذيب</Text>
          </TouchableOpacity>
        </View>
        {list.map((t, i) => (
          <View key={i} style={st.presetRow}>
            <Text style={st.presetTxt} numberOfLines={1}>{t}</Text>
            <TouchableOpacity onPress={() => setList(list.filter((_, x) => x !== i))}>
              <Text style={{color: colors.danger}}>🗑</Text>
            </TouchableOpacity>
          </View>
        ))}
        <View style={st.row}>
          <TextInput style={st.in} value={txt} onChangeText={setTxt} placeholder="نص جديد..." placeholderTextColor={colors.sub} />
          <TouchableOpacity style={st.addBtn} onPress={add}><Text style={{color: '#fff', fontWeight: '900'}}>＋</Text></TouchableOpacity>
        </View>
      </View>

      <View style={card}>
        <Text style={st.sec}>✨ مميزات أتمم</Text>
        {FEATURES.map(([ico, t, d], i) => (
          <View key={i} style={st.featRow}>
            <Text style={{fontSize: 20}}>{ico}</Text>
            <View style={{flex: 1}}>
              <Text style={st.featT}>{t}</Text>
              <Text style={st.featD}>{d}</Text>
            </View>
          </View>
        ))}
      </View>

      <View style={[card, {alignItems: 'center'}]}>
        <Text style={{fontSize: 26}}>✅</Text>
        <Text style={st.appName}>أتمم</Text>
        <Text style={st.hint}>الإصدار 1.0 — مهام · ملاحظات · غرف</Text>
      </View>
    </ScrollView>
  );
}

const st = StyleSheet.create({
  h: {fontSize: 22, fontWeight: '900', color: colors.text, textAlign: 'right', marginBottom: 12, marginTop: 8},
  sec: {fontWeight: '900', color: colors.text, textAlign: 'right', marginBottom: 6},
  hint: {color: colors.sub, fontSize: 11, textAlign: 'right', marginBottom: 10},
  row: {flexDirection: 'row-reverse', gap: 8, alignItems: 'center', marginBottom: 8},
  chip: {backgroundColor: colors.bg, borderRadius: 16, paddingHorizontal: 16, paddingVertical: 8, borderWidth: 1, borderColor: colors.border},
  on: {backgroundColor: colors.primary, borderColor: colors.primary},
  chipTxt: {fontWeight: '800', color: colors.text, fontSize: 12},
  presetRow: {flexDirection: 'row-reverse', alignItems: 'center', gap: 8, backgroundColor: colors.bg,
    borderRadius: 10, padding: 10, marginBottom: 6},
  presetTxt: {flex: 1, color: colors.text, fontWeight: '600', fontSize: 12, textAlign: 'right'},
  in: {flex: 1, backgroundColor: colors.bg, borderRadius: 10, padding: 10, textAlign: 'right', color: colors.text},
  addBtn: {backgroundColor: colors.primary, width: 42, height: 42, borderRadius: 12, alignItems: 'center', justifyContent: 'center'},
  featRow: {flexDirection: 'row-reverse', gap: 12, alignItems: 'center', paddingVertical: 8,
    borderBottomWidth: 0.5, borderColor: colors.border},
  featT: {fontWeight: '800', color: colors.text, textAlign: 'right'},
  featD: {color: colors.sub, fontSize: 11, textAlign: 'right'},
  appName: {fontWeight: '900', fontSize: 18, color: colors.primary},
});