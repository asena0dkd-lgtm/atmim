import React, {useState} from 'react';
import {View, Text, StyleSheet, FlatList, TouchableOpacity, Modal, TextInput} from 'react-native';
import {useApp} from '../context/AppContext';
import {colors, card} from '../theme/theme';

const BG_COLORS = ['#FFFFFF', '#FFF8EC', '#EEF4FF', '#1B1E28', '#E2F5F2'];
const BG_TYPES = [['grid', '▦ ورق بياني'], ['lines', '☰ دفتر خطوط'], ['dots', '⁙ نقاط تصميم']];

export default function RoomsScreen({navigation}) {
  const {rooms, addRoom, deleteRoom} = useApp();
  const [modal, setModal] = useState(false);
  const [name, setName] = useState('');
  const [bgColor, setBgColor] = useState(BG_COLORS[0]);
  const [bgType, setBgType] = useState('grid');

  const create = () => {
    const id = addRoom({name: name.trim() || 'غرفة جديدة', bgColor, bgType});
    setModal(false); setName('');
    navigation.navigate('roomCanvas', {id});
  };

  return (
    <View style={st.screen}>
      <View style={st.header}>
        <Text style={st.logo}>🎨 الغرف</Text>
        <Text style={st.sub}>مكان إنجاز مهامك — كانفاس بأدوات كاملة (وضع أفقي 16:9)</Text>
      </View>
      <FlatList
        data={rooms} keyExtractor={r => r.id} numColumns={2}
        contentContainerStyle={{padding: 12, paddingBottom: 100}}
        ListEmptyComponent={<View style={{alignItems: 'center', marginTop: 70}}>
          <Text style={{fontSize: 44}}>🚪</Text>
          <Text style={{color: colors.sub, fontWeight: '700', marginTop: 8}}>أنشئ غرفتك الأولى</Text>
        </View>}
        renderItem={({item}) => (
          <TouchableOpacity style={[st.roomCard, {backgroundColor: item.bgColor}]}
            onPress={() => navigation.navigate('roomCanvas', {id: item.id})} activeOpacity={0.85}>
            <Text style={{fontSize: 30}}>
              {item.bgType === 'grid' ? '▦' : item.bgType === 'lines' ? '☰' : '⁙'}
            </Text>
            <Text style={[st.roomName, item.bgColor === '#1B1E28' && {color: '#fff'}]} numberOfLines={1}>
              {item.name}
            </Text>
            <Text style={st.roomMeta}>{item.elements?.length || 0} عنصر</Text>
            <TouchableOpacity style={st.del} onPress={() => deleteRoom(item.id)}><Text>🗑</Text></TouchableOpacity>
          </TouchableOpacity>
        )}
      />
      <TouchableOpacity style={st.fab} onPress={() => setModal(true)}><Text style={st.fabTxt}>＋</Text></TouchableOpacity>

      <Modal visible={modal} transparent animationType="slide">
        <View style={st.modalBg}>
          <View style={st.modal}>
            <Text style={st.mTitle}>🚪 غرفة جديدة</Text>
            <TextInput style={st.mIn} value={name} onChangeText={setName}
              placeholder="اسم الغرفة (مثال: غرفة الدراسة)" placeholderTextColor={colors.sub} />
            <Text style={st.mLbl}>لون الخلفية</Text>
            <View style={st.swatches}>
              {BG_COLORS.map(c => (
                <TouchableOpacity key={c} style={[st.sw, {backgroundColor: c}, bgColor === c && st.swOn]}
                  onPress={() => setBgColor(c)} />
              ))}
            </View>
            <Text style={st.mLbl}>نوع الخلفية</Text>
            <View style={{flexDirection: 'row-reverse', gap: 8}}>
              {BG_TYPES.map(([k, l]) => (
                <TouchableOpacity key={k} style={[st.typeChip, bgType === k && st.typeOn]}
                  onPress={() => setBgType(k)}>
                  <Text style={{fontWeight: '800', color: bgType === k ? '#fff' : colors.text, fontSize: 12}}>{l}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <TouchableOpacity style={st.mCreate} onPress={create}>
              <Text style={{color: '#fff', fontWeight: '900'}}>إنشاء والدخول 🚪</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setModal(false)} style={{alignItems: 'center', marginTop: 10}}>
              <Text style={{color: colors.sub, fontWeight: '700'}}>إلغاء</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const st = StyleSheet.create({
  screen: {flex: 1, backgroundColor: colors.bg},
  header: {backgroundColor: colors.card, padding: 18, paddingTop: 24, borderBottomWidth: 1, borderColor: colors.border},
  logo: {fontSize: 22, fontWeight: '900', color: colors.text, textAlign: 'right'},
  sub: {color: colors.sub, fontWeight: '600', marginTop: 4, textAlign: 'right', fontSize: 12},
  roomCard: {flex: 1, margin: 6, borderRadius: 18, padding: 16, minHeight: 130,
    borderWidth: 1, borderColor: colors.border, justifyContent: 'center', gap: 4},
  roomName: {fontWeight: '900', fontSize: 15, color: colors.text, textAlign: 'right'},
  roomMeta: {color: colors.sub, fontSize: 11, fontWeight: '700', textAlign: 'right'},
  del: {position: 'absolute', top: 8, left: 8},
  fab: {position: 'absolute', left: 20, bottom: 24, width: 58, height: 58, borderRadius: 29,
    backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', elevation: 6},
  fabTxt: {color: '#fff', fontSize: 30, fontWeight: '700', marginTop: -2},
  modalBg: {flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end'},
  modal: {backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20},
  mTitle: {fontWeight: '900', fontSize: 18, color: colors.text, textAlign: 'right', marginBottom: 12},
  mIn: {backgroundColor: colors.bg, borderRadius: 12, padding: 12, textAlign: 'right',
    color: colors.text, fontWeight: '600'},
  mLbl: {fontWeight: '800', color: colors.text, marginTop: 14, marginBottom: 8, textAlign: 'right'},
  swatches: {flexDirection: 'row-reverse', gap: 10},
  sw: {width: 38, height: 38, borderRadius: 19, borderWidth: 2, borderColor: colors.border},
  swOn: {borderColor: colors.primary, transform: [{scale: 1.1}]},
  typeChip: {backgroundColor: colors.bg, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 10,
    borderWidth: 1, borderColor: colors.border},
  typeOn: {backgroundColor: colors.primary, borderColor: colors.primary},
  mCreate: {backgroundColor: colors.primary, borderRadius: 14, padding: 14, alignItems: 'center', marginTop: 18},
});