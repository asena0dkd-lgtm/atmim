import React, {useEffect, useRef, useState} from 'react';
import {View, Text, TextInput, StyleSheet, TouchableOpacity, Modal,
  PanResponder, Dimensions, Image, Alert, Share, ScrollView} from 'react-native';
import Svg, {Rect, Defs, Pattern, Line, Circle, Polyline} from 'react-native-svg';
import Orientation from 'react-native-orientation-locker';
import {captureRef} from 'react-native-view-shot';
import {useApp} from '../context/AppContext';
import Sketch, {pts2str} from '../components/Sketch';
import {colors} from '../theme/theme';
import {uid, fmtRemain} from '../utils/helpers';

const W = 2400, H = 1600; // مساحة الكانفاس
const STAMPS = [['ممتاز', '#12B76A'], ['رائع', '#0E9384'], ['جيد', '#FF8A00'],
  ['حاول مرةً أخرى', '#E5484D'], ['سيء', '#7A271A']];

// ---------- مؤقت ----------
function TimerEl({data, onPatch}) {
  const [remain, setRemain] = useState(data.remain ?? data.minutes * 60000);
  const [on, setOn] = useState(false);
  useEffect(() => {
    if (!on) return;
    const iv = setInterval(() => {
      setRemain(r => {
        if (r <= 1000) {setOn(false); Alert.alert('⏰', 'انتهى المؤقت!'); return data.minutes * 60000;}
        return r - 1000;
      });
    }, 1000);
    return () => clearInterval(iv);
  }, [on]);
  return (
    <View style={st.timer}>
      <Text style={st.timerTxt}>{fmtRemain(remain)}</Text>
      <View style={{flexDirection: 'row', gap: 6}}>
        <TouchableOpacity onPress={() => setOn(!on)} style={st.tBtn}>
          <Text style={st.tBtnTxt}>{on ? '⏸' : '▶'}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => {setOn(false); setRemain(data.minutes * 60000);}} style={st.tBtn}>
          <Text style={st.tBtnTxt}>↺</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => onPatch({minutes: data.minutes + 5, remain: (data.minutes + 5) * 60000})} style={st.tBtn}>
          <Text style={st.tBtnTxt}>+5</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

// ---------- دفتر بصفحات ----------
function NotebookModal({el, onClose, onPatch}) {
  const pages = el.data.pages || [{id: uid(), text: '', paths: []}];
  const [idx, setIdx] = useState(0);
  const [draw, setDraw] = useState(false);
  const page = pages[idx];
  const setPages = p => onPatch({pages: p});
  const updPage = patch => setPages(pages.map((p, i) => (i === idx ? {...p, ...patch} : p)));
  return (
    <Modal visible animationType="slide">
      <View style={nb.screen}>
        <View style={nb.bar}>
          <TouchableOpacity onPress={onClose}><Text style={{fontSize: 18}}>✕</Text></TouchableOpacity>
          <Text style={nb.title}>📓 الدفتر — صفحة {idx + 1}/{pages.length}</Text>
          <TouchableOpacity onPress={() => setDraw(!draw)} style={[nb.dBtn, draw && {backgroundColor: colors.primary}]}>
            <Text style={{color: draw ? '#fff' : colors.text, fontWeight: '800'}}>✏️ رسم</Text>
          </TouchableOpacity>
        </View>
        <View style={{flex: 1}}>
          <TextInput style={nb.page} multiline value={page.text}
            onChangeText={t => updPage({text: t})} placeholder="اكتب ملاحظاتك، معادلاتك..." placeholderTextColor={colors.sub} />
          <Svg style={StyleSheet.absoluteFill} pointerEvents="none">
            {page.paths.map((p, i) => <Polyline key={i} points={pts2str(p.pts)} stroke={p.color} strokeWidth={3} fill="none" />)}
          </Svg>
          {draw && <View style={StyleSheet.absoluteFill}>
            <Sketch paths={[]} onChange={np => updPage({paths: [...page.paths, ...np]})} />
          </View>}
        </View>
        <View style={nb.nav}>
          <TouchableOpacity disabled={idx === 0} onPress={() => setIdx(idx - 1)}><Text style={nb.navTxt}>‹ السابقة</Text></TouchableOpacity>
          <TouchableOpacity onPress={() => {setPages([...pages, {id: uid(), text: '', paths: []}]); setIdx(pages.length);}}>
            <Text style={[nb.navTxt, {color: colors.primary}]}>＋ صفحة</Text>
          </TouchableOpacity>
          <TouchableOpacity disabled={idx === pages.length - 1} onPress={() => setIdx(idx + 1)}><Text style={nb.navTxt}>التالية ›</Text></TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

// ---------- شاشتا الكود ----------
function CodeModal({el, onClose, onPatch}) {
  const [tab, setTab] = useState('html');
  const [screen, setScreen] = useState(1); // 1=الكود 2=المعاينة
  const d = el.data;
  let WebView = null;
  try {WebView = require('react-native-webview').WebView;} catch (e) {}
  const src = `<html dir="ltr"><head><style>${d.css || ''}</style></head><body>${d.html || ''}<script>${d.js || ''}<\/script></body></html>`;
  return (
    <Modal visible animationType="slide">
      <View style={{flex: 1, backgroundColor: '#0F1117'}}>
        <View style={nb.bar}>
          <TouchableOpacity onPress={onClose}><Text style={{fontSize: 18}}>✕</Text></TouchableOpacity>
          <Text style={nb.title}>💻 محرر الأكواد</Text>
          <TouchableOpacity style={nb.dBtn} onPress={() => setScreen(screen === 1 ? 2 : 1)}>
            <Text style={{fontWeight: '800', color: colors.text}}>{screen === 1 ? '👁 المعاينة' : '</> الكود'}</Text>
          </TouchableOpacity>
        </View>
        {screen === 1 ? (
          <>
            <View style={{flexDirection: 'row', gap: 6, padding: 8}}>
              {['html', 'css', 'js'].map(k => (
                <TouchableOpacity key={k} style={[codeSt.tab, tab === k && {backgroundColor: colors.primary}]}
                  onPress={() => setTab(k)}>
                  <Text style={{color: '#fff', fontWeight: '800'}}>{k.toUpperCase()}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <TextInput style={codeSt.editor} multiline value={d[tab] || ''}
              onChangeText={t => onPatch({[tab]: t})} placeholder={`اكتب كود ${tab.toUpperCase()}...`}
              placeholderTextColor="#556" autoCapitalize="none" />
          </>
        ) : (
          WebView ? <WebView source={{html: src}} originWhitelist={['*']} style={{flex: 1}} />
            : <Text style={{color: '#fff', padding: 20}}>ثبّت: npm i react-native-webview</Text>
        )}
      </View>
    </Modal>
  );
}

// ---------- الشاشة الرئيسية للغرفة ----------
export default function RoomCanvasScreen({route, navigation}) {
  const {rooms, updateRoom} = useApp();
  const room = rooms.find(r => r.id === route.params.id);
  const [tool, setTool] = useState('hand'); // hand | select
  const [toolsOn, setToolsOn] = useState(false);
  const [drawOn, setDrawOn] = useState(false);
  const [pen, setPen] = useState('#E5484D');
  const [openEl, setOpenEl] = useState(null);
  const [pan, setPan] = useState({x: 0, y: 0});
  const [zoom, setZoom] = useState(0.6);
  const [selId, setSelId] = useState(null);
  const panRef = useRef({x: 0, y: 0});
  const zoomRef = useRef(0.6);
  const pinchRef = useRef(null);
  const canvasRef = useRef();
  const scr = Dimensions.get('window');

  useEffect(() => {
    try {Orientation.lockToLandscape();} catch (e) {}
    return () => {try {Orientation.unlockAllOrientations();} catch (e) {}};
  }, []);

  if (!room) return null;
  const setP = p => {panRef.current = p; setPan(p);};
  const setZ = z => {z = Math.max(0.2, Math.min(3, z)); zoomRef.current = z; setZoom(z);};

  // أداة اليد: سحب + زوم بإصبعين
  const handPR = useRef(PanResponder.create({
    onStartShouldSetPanResponder: () => tool === 'hand',
    onMoveShouldSetPanResponder: () => tool === 'hand',
    onPanResponderGrant: e => {
      const t = e.nativeEvent.touches;
      if (t.length === 2) {
        const d = Math.hypot(t[0].pageX - t[1].pageX, t[0].pageY - t[1].pageY);
        pinchRef.current = {d0: d, z0: zoomRef.current};
      }
    },
    onPanResponderMove: (e, g) => {
      const t = e.nativeEvent.touches;
      if (t.length === 2 && pinchRef.current) {
        const d = Math.hypot(t[0].pageX - t[1].pageX, t[0].pageY - t[1].pageY);
        setZ(pinchRef.current.z0 * (d / pinchRef.current.d0));
        return;
      }
      if (t.length === 1 && !pinchRef.current?._moved) {
        setP({x: panRef.current.x + g.dx - (handPR._last?.dx || 0) + 0, y: panRef.current.y}); // fallback
      }
    },
    onPanResponderRelease: () => {pinchRef.current = null; handPR._last = null;},
  })).current;

  // سحب بسيط بإصبع واحد (أدق من المركّب أعلاه)
  const dragPR = useRef(PanResponder.create({
    onStartShouldSetPanResponder: () => tool === 'hand',
    onMoveShouldSetPanResponder: () => tool === 'hand',
    onPanResponderMove: (e, g) => {
      if (e.nativeEvent.touches.length === 1 && !pinchRef.current) {
        if (!dragPR._s) dragPR._s = {...panRef.current};
        setP({x: dragPR._s.x + g.dx, y: dragPR._s.y + g.dy});
      }
    },
    onPanResponderRelease: () => {dragPR._s = null; pinchRef.current = null;},
  })).current;

  const addEl = (type, data = {}) => {
    const cx = (-panRef.current.x + scr.width / 2) / zoomRef.current;
    const cy = (-panRef.current.y + scr.height / 2) / zoomRef.current;
    const el = {id: uid(), type, x: cx - 100, y: cy - 70, data};
    updateRoom(room.id, {elements: [...room.elements, el]});
    setToolsOn(false);
    setSelId(el.id);
    setTool('select');
  };

  const patchEl = (id, patch) =>
    updateRoom(room.id, {elements: room.elements.map(e => (e.id === id ? {...e, ...patch} : e))});
  const patchData = (id, dp) =>
    updateRoom(room.id, {elements: room.elements.map(e => (e.id === id ? {...e, data: {...e.data, ...dp}} : e))});
  const delEl = id =>
    updateRoom(room.id, {elements: room.elements.filter(e => e.id !== id)});

  const pickImage = async () => {
    try {
      const {launchImageLibrary} = require('react-native-image-picker');
      const r = await launchImageLibrary({mediaType: 'mixed', selectionLimit: 1});
      const a = r.assets?.[0];
      if (a) addEl('image', {uri: a.uri, name: a.fileName || 'صورة', w: a.width, h: a.height});
    } catch (e) {
      Alert.alert('صور', 'ثبّت الحزمة: npm i react-native-image-picker');
    }
  };

  const exportImage = async () => {
    try {
      const uri = await captureRef(canvasRef, {format: 'png', quality: 1});
      await Share.share({url: uri, message: `غرفة «${room.name}» من تطبيق أتمم`});
    } catch (e) {
      Alert.alert('تصدير', 'ثبّت الحزمة: npm i react-native-view-shot');
    }
  };

  // عنصر قابل للتحديد والتحريك مع تمرير تلقائي عند الحواف
  const Element = ({el}) => {
    const sel = selId === el.id;
    const pr = useRef(PanResponder.create({
      onStartShouldSetPanResponder: () => tool === 'select',
      onPanResponderGrant: () => setSelId(el.id),
      onPanResponderMove: (e, g) => {
        if (!pr._s) pr._s = {x: el.x, y: el.y};
        let nx = pr._s.x + g.dx / zoomRef.current;
        let ny = pr._s.y + g.dy / zoomRef.current;
        patchEl(el.id, {x: nx, y: ny});
        // تمرير تلقائي عند حواف الشاشة (الشاشة تمشي مع العنصر)
        const mx = e.nativeEvent.pageX, my = e.nativeEvent.pageY;
        const M = 40, S = 14;
        if (mx < M) setP({...panRef.current, x: panRef.current.x + S});
        if (mx > scr.width - M) setP({...panRef.current, x: panRef.current.x - S});
        if (my < M) setP({...panRef.current, y: panRef.current.y + S});
        if (my > scr.height - M) setP({...panRef.current, y: panRef.current.y - S});
      },
      onPanResponderRelease: () => (pr._s = null),
    })).current;

    const ar = el.data.w && el.data.h ? el.data.w / el.data.h : 16 / 9;
    return (
      <View {...pr.panHandlers}
        style={[st.el, {left: el.x, top: el.y, transform: [{scale: sel ? 1.06 : 1}]},
          sel && st.elSel]}>
        {el.type === 'image' && (
          el.data.uri
            ? <Image source={{uri: el.data.uri}} style={{width: 220, height: 220 / ar, borderRadius: 10}} resizeMode="contain" />
            : <Text style={st.elIco}>🖼️ {el.data.name}</Text>
        )}
        {el.type === 'notebook' && (
          <TouchableOpacity style={st.elBox} onPress={() => setOpenEl(el)}>
            <Text style={st.elIco}>📓 دفتر ({(el.data.pages || []).length || 1} صفحات)</Text>
          </TouchableOpacity>
        )}
        {el.type === 'code' && (
          <TouchableOpacity style={st.elBox} onPress={() => setOpenEl(el)}>
            <Text style={st.elIco}>💻 شاشة كود</Text>
          </TouchableOpacity>
        )}
        {el.type === 'stamp' && (
          <View style={[st.stamp, {borderColor: el.data.color}]}>
            <Text style={[st.stampTxt, {color: el.data.color}]}>{el.data.text} ✓</Text>
          </View>
        )}
        {el.type === 'timer' && <TimerEl data={el.data} onPatch={p => patchData(el.id, p)} />}
        {el.type === 'text' && (
          <TextInput style={st.textEl} value={el.data.text} multiline
            onChangeText={t => patchData(el.id, {text: t})} placeholder="نص..." placeholderTextColor={colors.sub} />
        )}
        {el.type === 'ruler' && (
          <Svg width={300} height={40}>
            <Rect x={0} y={0} width={300} height={30} fill="#FFF3D6" stroke="#D9A441" />
            {Array.from({length: 31}).map((_, i) => (
              <Line key={i} x1={i * 10} y1={0} x2={i * 10} y2={i % 5 === 0 ? 14 : 7} stroke="#8a6d2f" strokeWidth={1} />
            ))}
          </Svg>
        )}
        {sel && (
          <TouchableOpacity style={st.elDel} onPress={() => {delEl(el.id); setSelId(null);}}>
            <Text style={{color: '#fff', fontSize: 10, fontWeight: '900'}}>✕</Text>
          </TouchableOpacity>
        )}
      </View>
    );
  };

  const bgStroke = room.bgColor === '#1B1E28' ? '#2A2E3C' : '#E3E6EC';
  const pattern =
    room.bgType === 'grid' ? (
      <Pattern id="p" width={40} height={40} patternUnits="userSpaceOnUse">
        <Line x1={0} y1={0} x2={0} y2={40} stroke={bgStroke} strokeWidth={1} />
        <Line x1={0} y1={0} x2={40} y2={0} stroke={bgStroke} strokeWidth={1} />
      </Pattern>
    ) : room.bgType === 'lines' ? (
      <Pattern id="p" width={60} height={44} patternUnits="userSpaceOnUse">
        <Line x1={0} y1={0} x2={60} y2={0} stroke={bgStroke} strokeWidth={1} />
      </Pattern>
    ) : (
      <Pattern id="p" width={36} height={36} patternUnits="userSpaceOnUse">
        <Circle cx={2} cy={2} r={1.6} fill={bgStroke} />
      </Pattern>
    );

  const TOOLS = [
    ['🖼️ صورة / فيديو', pickImage],
    ['📓 دفتر', () => addEl('notebook', {pages: [{id: uid(), text: '', paths: []}]})],
    ['💻 شاشة كود', () => addEl('code', {html: '<h1>مرحباً</h1>', css: '', js: ''})],
    ['⏱ مؤقت', () => addEl('timer', {minutes: 25})],
    ['📏 مسطرة', () => addEl('ruler', {})],
    ['🔤 نص', () => addEl('text', {text: ''})],
    ['🏅 طابع', () => Alert.alert('اختر طابعاً', '', STAMPS.map(([t, c]) => ({text: t, onPress: () => addEl('stamp', {text: t, color: c})})).concat([{text: 'إلغاء'}]))],
    [drawOn ? '✓ إنهاء الرسم' : '✏️ رسم حر', () => setDrawOn(!drawOn)],
  ];

  return (
    <View style={st.screen}>
      {/* الكانفاس */}
      <View ref={canvasRef} collapsable={false} style={StyleSheet.absoluteFill}
        {...(tool === 'hand' ? dragPR.panHandlers : {})}
        {...(tool === 'hand' ? handPR.panHandlers : {})}>
        <View style={{width: W, height: H, transform: [{translateX: pan.x}, {translateY: pan.y}, {scale: zoom}]}}>
          <Svg width={W} height={H}>
            <Defs>{pattern}</Defs>
            <Rect width={W} height={H} fill={room.bgColor} />
            <Rect width={W} height={H} fill="url(#p)" />
            {(room.drawings || []).map((p, i) => (
              <Polyline key={i} points={pts2str(p.pts)} stroke={p.color} strokeWidth={3 / zoom} fill="none" strokeLinecap="round" />
            ))}
          </Svg>
          {room.elements.map(el => <Element key={el.id} el={el} />)}
          {drawOn && (
            <View style={[StyleSheet.absoluteFill, {width: W, height: H}]}>
              <Sketch paths={[]} color={pen}
                onChange={np => updateRoom(room.id, {drawings: [...(room.drawings || []), ...np]})} />
            </View>
          )}
        </View>
      </View>

      {/* ألوان القلم */}
      {drawOn && (
        <View style={st.penRow}>
          {['#E5484D', '#FF8A00', '#0E9384', '#3E63DD', '#1B1E28'].map(c => (
            <TouchableOpacity key={c} onPress={() => setPen(c)}
              style={[st.pen, {backgroundColor: c}, pen === c && {borderColor: '#fff', borderWidth: 3}]} />
          ))}
          <TouchableOpacity onPress={() => updateRoom(room.id, {drawings: []})} style={st.sideBtn}>
            <Text style={st.sideIco}>🧹</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* الأزرار الجانبية (يمين) */}
      <View style={st.side}>
        <TouchableOpacity style={[st.sideBtn, tool === 'hand' && st.sideOn]} onPress={() => setTool('hand')}>
          <Text style={st.sideIco}>✋</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[st.sideBtn, tool === 'select' && st.sideOn]} onPress={() => {setTool('select'); setSelId(null);}}>
          <Text style={st.sideIco}>👆</Text>
        </TouchableOpacity>
        <TouchableOpacity style={st.sideBtn} onPress={() => setToolsOn(true)}>
          <Text style={st.sideIco}>🧰</Text>
        </TouchableOpacity>
        <TouchableOpacity style={st.sideBtn} onPress={() => setZ(zoomRef.current + 0.15)}>
          <Text style={st.sideIco}>🔍＋</Text>
        </TouchableOpacity>
        <TouchableOpacity style={st.sideBtn} onPress={() => setZ(zoomRef.current - 0.15)}>
          <Text style={st.sideIco}>🔍－</Text>
        </TouchableOpacity>
        <TouchableOpacity style={st.sideBtn} onPress={exportImage}>
          <Text style={st.sideIco}>📸</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[st.sideBtn, {backgroundColor: colors.dangerSoft}]} onPress={() => navigation.goBack()}>
          <Text style={st.sideIco}>🚪</Text>
        </TouchableOpacity>
      </View>

      {/* اسم الغرفة */}
      <View style={st.nameTag}><Text style={st.nameTxt}>🎨 {room.name}</Text></View>

      {/* شاشة الأدوات */}
      <Modal visible={toolsOn} transparent animationType="slide">
        <TouchableOpacity style={st.toolsBg} activeOpacity={1} onPress={() => setToolsOn(false)}>
          <View style={st.toolsSheet}>
            <Text style={st.toolsTitle}>🧰 شاشة الأدوات</Text>
            <View style={st.toolsGrid}>
              {TOOLS.map(([l, fn], i) => (
                <TouchableOpacity key={i} style={st.toolItem} onPress={fn}>
                  <Text style={st.toolTxt}>{l}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </TouchableOpacity>
      </Modal>

      {/* نوافذ العناصر */}
      {openEl?.type === 'notebook' && (
        <NotebookModal el={openEl} onClose={() => setOpenEl(null)} onPatch={p => patchData(openEl.id, p)} />
      )}
      {openEl?.type === 'code' && (
        <CodeModal el={openEl} onClose={() => setOpenEl(null)} onPatch={p => patchData(openEl.id, p)} />
      )}
    </View>
  );
}

const st = StyleSheet.create({
  screen: {flex: 1, backgroundColor: '#333'},
  el: {position: 'absolute', borderRadius: 10},
  elSel: {borderWidth: 2, borderColor: colors.primary, shadowColor: colors.primary,
    shadowOpacity: 0.6, shadowRadius: 12, elevation: 8, backgroundColor: 'rgba(255,138,0,0.06)'},
  elBox: {backgroundColor: '#fff', borderRadius: 12, padding: 16, borderWidth: 1, borderColor: colors.border, elevation: 3},
  elIco: {fontWeight: '800', color: colors.text},
  elDel: {position: 'absolute', top: -10, left: -10, backgroundColor: colors.danger,
    width: 22, height: 22, borderRadius: 11, alignItems: 'center', justifyContent: 'center'},
  stamp: {borderWidth: 3, borderRadius: 12, paddingHorizontal: 18, paddingVertical: 8,
    transform: [{rotate: '-8deg'}], backgroundColor: 'rgba(255,255,255,0.85)'},
  stampTxt: {fontWeight: '900', fontSize: 18},
  timer: {backgroundColor: '#1B1E28', borderRadius: 14, padding: 14, alignItems: 'center', gap: 8},
  timerTxt: {color: '#fff', fontWeight: '900', fontSize: 22, fontVariant: ['tabular-nums']},
  tBtn: {backgroundColor: '#2A2E3C', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6},
  tBtnTxt: {color: colors.primary, fontWeight: '900'},
  textEl: {backgroundColor: 'rgba(255,255,255,0.9)', borderRadius: 10, padding: 12,
    minWidth: 160, color: colors.text, fontWeight: '700', textAlign: 'right'},
  side: {position: 'absolute', right: 12, top: 20, gap: 10},
  sideBtn: {width: 52, height: 52, borderRadius: 26, backgroundColor: '#fff',
    alignItems: 'center', justifyContent: 'center', elevation: 5},
  sideOn: {backgroundColor: colors.primarySoft, borderWidth: 2, borderColor: colors.primary},
  sideIco: {fontSize: 20},
  penRow: {position: 'absolute', left: 16, bottom: 16, flexDirection: 'row', gap: 10, alignItems: 'center'},
  pen: {width: 30, height: 30, borderRadius: 15},
  nameTag: {position: 'absolute', top: 14, left: 14, backgroundColor: 'rgba(255,255,255,0.92)',
    borderRadius: 14, paddingHorizontal: 14, paddingVertical: 8, elevation: 4},
  nameTxt: {fontWeight: '900', color: colors.text},
  toolsBg: {flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end'},
  toolsSheet: {backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20},
  toolsTitle: {fontWeight: '900', fontSize: 18, color: colors.text, textAlign: 'center', marginBottom: 14},
  toolsGrid: {flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 10},
  toolItem: {backgroundColor: colors.bg, borderRadius: 14, paddingHorizontal: 16, paddingVertical: 14,
    borderWidth: 1, borderColor: colors.border},
  toolTxt: {fontWeight: '800', color: colors.text},
});

const nb = StyleSheet.create({
  screen: {flex: 1, backgroundColor: colors.bg},
  bar: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: '#fff', padding: 14, borderBottomWidth: 1, borderColor: colors.border},
  title: {fontWeight: '900', color: colors.text},
  dBtn: {backgroundColor: colors.bg, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 7},
  page: {flex: 1, margin: 14, backgroundColor: '#FFF8EC', borderRadius: 14, padding: 16,
    textAlign: 'right', textAlignVertical: 'top', color: colors.text, fontSize: 15, lineHeight: 26},
  nav: {flexDirection: 'row', justifyContent: 'space-around', backgroundColor: '#fff',
    padding: 14, borderTopWidth: 1, borderColor: colors.border},
  navTxt: {fontWeight: '800', color: colors.text},
});

const codeSt = StyleSheet.create({
  tab: {backgroundColor: '#1E2230', borderRadius: 8, paddingHorizontal: 16, paddingVertical: 8},
  editor: {flex: 1, backgroundColor: '#161A26', color: '#7EE787', margin: 10, borderRadius: 12,
    padding: 14, fontFamily: 'monospace', textAlign: 'left', textAlignVertical: 'top', fontSize: 14},
});