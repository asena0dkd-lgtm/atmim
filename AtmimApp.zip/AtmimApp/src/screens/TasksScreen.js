import React, {useEffect, useState} from 'react';
import {View, Text, StyleSheet, FlatList, TouchableOpacity, ScrollView} from 'react-native';
import {useApp} from '../context/AppContext';
import TaskCard from '../components/TaskCard';
import {colors} from '../theme/theme';
import {toAr} from '../utils/helpers';

export default function TasksScreen({navigation}) {
  const {tasks, notes, completeTask, failTask, startPomodoroIfDue} = useApp();
  const [tab, setTab] = useState('active');

  useEffect(() => {
    startPomodoroIfDue();
    const iv = setInterval(startPomodoroIfDue, 5000);
    return () => clearInterval(iv);
  }, [tasks]);

  const visible = tasks.filter(t => !t.hidden && t.status !== 'cancelled');
  const lists = {
    active: visible.filter(t => t.status === 'active'),
    done: visible.filter(t => t.status === 'done'),
    failed: visible.filter(t => t.status === 'failed'),
  };
  const total = lists.active.length + lists.done.length;
  const pct = total ? Math.round((lists.done.length / total) * 100) : 0;
  const noteOf = id => notes.find(n => n.id === id);

  return (
    <View style={st.screen}>
      <View style={st.header}>
        <Text style={st.logo}>✅ أتمم</Text>
        <Text style={st.sub}>اليوم — {toAr(lists.done.length)} / {toAr(total)} مهام · {toAr(pct)}٪</Text>
        <View style={st.pTrack}><View style={[st.pFill, {width: `${pct}%`}]} /></View>
      </View>

      <View style={st.tabs}>
        {[['active', 'الكل'], ['done', 'المكتملة'], ['failed', 'الفاشلة']].map(([k, l]) => (
          <TouchableOpacity key={k} style={[st.tab, tab === k && st.tabOn]} onPress={() => setTab(k)}>
            <Text style={[st.tabTxt, tab === k && st.tabTxtOn]}>{l} ({toAr(lists[k].length)})</Text>
          </TouchableOpacity>
        ))}
      </View>

      <FlatList
        data={lists[tab]}
        keyExtractor={t => t.id}
        contentContainerStyle={{padding: 16, paddingBottom: 100}}
        ListEmptyComponent={
          <View style={st.empty}>
            <Text style={{fontSize: 44}}>{tab === 'done' ? '🏆' : tab === 'failed' ? '📋' : '☕'}</Text>
            <Text style={st.emptyTxt}>
              {tab === 'done' ? 'لا مهام مكتملة بعد — أنت تستطيع!' :
               tab === 'failed' ? 'لا مهام فاشلة، ممتاز!' : 'لا مهام حالياً، أضف مهمة جديدة'}
            </Text>
          </View>
        }
        renderItem={({item}) => (
          <TaskCard task={item} note={noteOf(item.noteId)}
            onPress={() => navigation.navigate('taskDetail', {id: item.id})}
            onDone={completeTask}
            onPomodoroEnd={failTask} />
        )}
      />

      <TouchableOpacity style={st.fab} onPress={() => navigation.navigate('addTask')}>
        <Text style={st.fabTxt}>＋</Text>
      </TouchableOpacity>
    </View>
  );
}

const st = StyleSheet.create({
  screen: {flex: 1, backgroundColor: colors.bg},
  header: {backgroundColor: colors.card, padding: 18, paddingTop: 24, borderBottomWidth: 1, borderColor: colors.border},
  logo: {fontSize: 24, fontWeight: '900', color: colors.primary, textAlign: 'right'},
  sub: {color: colors.sub, marginTop: 4, fontWeight: '600', textAlign: 'right'},
  pTrack: {height: 6, borderRadius: 3, backgroundColor: colors.border, marginTop: 10, overflow: 'hidden'},
  pFill: {height: 6, borderRadius: 3, backgroundColor: colors.primary},
  tabs: {flexDirection: 'row-reverse', paddingHorizontal: 16, paddingTop: 12, gap: 8},
  tab: {paddingVertical: 7, paddingHorizontal: 16, borderRadius: 20, backgroundColor: colors.card},
  tabOn: {backgroundColor: colors.primary},
  tabTxt: {fontWeight: '700', color: colors.sub, fontSize: 13},
  tabTxtOn: {color: '#fff'},
  empty: {alignItems: 'center', marginTop: 80, gap: 10},
  emptyTxt: {color: colors.sub, fontWeight: '600'},
  fab: {position: 'absolute', left: 20, bottom: 24, width: 58, height: 58, borderRadius: 29,
    backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', elevation: 6},
  fabTxt: {color: '#fff', fontSize: 30, fontWeight: '700', marginTop: -2},
});