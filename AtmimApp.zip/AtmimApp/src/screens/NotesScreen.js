import React, {useState} from 'react';
import {View, Text, StyleSheet, FlatList, TouchableOpacity, TextInput} from 'react-native';
import {useApp} from '../context/AppContext';
import {colors, card} from '../theme/theme';
import {fmtDate} from '../utils/helpers';

export default function NotesScreen({navigation}) {
  const {notes, addNote, deleteNote} = useApp();
  const [q, setQ] = useState('');
  const list = notes.filter(n => !q || n.title.includes(q) ||
    n.blocks?.some(b => b.text?.includes(q)));

  const open = id => navigation.navigate('noteEditor', {id});
  const create = () => {const id = addNote({title: 'بدون عنوان'}); open(id);};

  return (
    <View style={st.screen}>
      <View style={st.header}>
        <Text style={st.logo}>📝 الملاحظات</Text>
        <View style={st.search}>
          <TextInput style={st.searchIn} value={q} onChangeText={setQ}
            placeholder="ابحث في الملاحظات..." placeholderTextColor={colors.sub} />
          <Text>🔍</Text>
        </View>
      </View>
      <FlatList
        data={list}
        keyExtractor={n => n.id}
        contentContainerStyle={{padding: 16, paddingBottom: 100}}
        ListEmptyComponent={<View style={{alignItems: 'center', marginTop: 70}}>
          <Text style={{fontSize: 44}}>🗒️</Text>
          <Text style={{color: colors.sub, fontWeight: '700', marginTop: 8}}>لا ملاحظات — أنشئ أول ملاحظة</Text>
        </View>}
        renderItem={({item}) => (
          <TouchableOpacity style={card} onPress={() => open(item.id)} activeOpacity={0.85}>
            <View style={{flexDirection: 'row-reverse', justifyContent: 'space-between'}}>
              <Text style={st.title} numberOfLines={1}>{item.title}</Text>
              <TouchableOpacity onPress={() => deleteNote(item.id)}><Text>🗑</Text></TouchableOpacity>
            </View>
            <Text style={st.preview} numberOfLines={2}>
              {item.blocks?.map(b => b.text || '[جدول]').filter(Boolean).join(' · ') || 'فارغة'}
            </Text>
            <Text style={st.date}>{fmtDate(item.createdAt)}</Text>
          </TouchableOpacity>
        )}
      />
      <TouchableOpacity style={st.fab} onPress={create}><Text style={st.fabTxt}>＋</Text></TouchableOpacity>
    </View>
  );
}

const st = StyleSheet.create({
  screen: {flex: 1, backgroundColor: colors.bg},
  header: {backgroundColor: colors.card, padding: 18, paddingTop: 24, borderBottomWidth: 1, borderColor: colors.border},
  logo: {fontSize: 22, fontWeight: '900', color: colors.text, textAlign: 'right'},
  search: {flexDirection: 'row', alignItems: 'center', backgroundColor: colors.bg,
    borderRadius: 12, paddingHorizontal: 12, marginTop: 12},
  searchIn: {flex: 1, padding: 10, textAlign: 'right', color: colors.text, fontWeight: '600'},
  title: {fontSize: 15, fontWeight: '800', color: colors.text, flex: 1, textAlign: 'right'},
  preview: {color: colors.sub, fontSize: 12, marginTop: 6, textAlign: 'right', lineHeight: 18},
  date: {color: colors.sub, fontSize: 10, marginTop: 8, textAlign: 'left'},
  fab: {position: 'absolute', left: 20, bottom: 24, width: 58, height: 58, borderRadius: 29,
    backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', elevation: 6},
  fabTxt: {color: '#fff', fontSize: 30, fontWeight: '700', marginTop: -2},
});