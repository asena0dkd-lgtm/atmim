import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import {colors, card} from '../theme/theme';
import {toAr, fmtTime} from '../utils/helpers';
import PomodoroBar from './PomodoroBar';

export default function TaskCard({task, note, onPress, onDone, onPomodoroEnd}) {
  const running = !!task.pomodoroStartedAt && task.status === 'active';
  return (
    <TouchableOpacity style={[card, st.row]} onPress={onPress} activeOpacity={0.85}>
      <View style={[st.edge, task.status === 'done' && {backgroundColor: colors.green},
        task.status === 'failed' && {backgroundColor: colors.danger}]} />
      <TouchableOpacity
        style={[st.check, task.status === 'done' && st.checkOn]}
        onPress={() => onDone(task.id)}>
        {task.status === 'done' && <Text style={st.checkMark}>✓</Text>}
      </TouchableOpacity>

      <View style={{flex: 1}}>
        <Text style={[st.title, task.status !== 'active' && st.muted]} numberOfLines={1}>
          {task.title}
        </Text>
        <View style={st.metaRow}>
          {!!task.scheduledAt && <Text style={st.meta}>🕐 {fmtTime(task.scheduledAt)}</Text>}
          {!!task.pomodoro && <Text style={st.meta}>⏳ {toAr(task.pomodoro)} د</Text>}
          {task.repeat !== 'none' && <Text style={st.meta}>🔁</Text>}
          {!!note && <Text style={[st.meta, {color: colors.teal}]}>📝 {note.title}</Text>}
          {!!task.attachments?.length && <Text style={st.meta}>📎 {toAr(task.attachments.length)}</Text>}
        </View>
        {running && (
          <PomodoroBar totalMinutes={task.pomodoro} startedAt={task.pomodoroStartedAt}
            onEnd={() => onPomodoroEnd(task.id)} />
        )}
      </View>

      {task.failCount > 0 && task.status === 'active' && (
        <View style={st.count}>
          <Text style={st.countTxt}>{toAr(task.failCount)}</Text>
          <Text style={st.countLbl}>فشل</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

const st = StyleSheet.create({
  row: {flexDirection: 'row', alignItems: 'center', gap: 10, overflow: 'hidden'},
  edge: {position: 'absolute', right: 0, top: 0, bottom: 0, width: 4, backgroundColor: colors.primary},
  check: {width: 24, height: 24, borderRadius: 7, borderWidth: 2, borderColor: colors.border,
    alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff'},
  checkOn: {backgroundColor: colors.teal, borderColor: colors.teal},
  checkMark: {color: '#fff', fontSize: 13, fontWeight: '900'},
  title: {fontSize: 15, fontWeight: '700', color: colors.text, textAlign: 'right'},
  muted: {color: colors.sub, textDecorationLine: 'line-through'},
  metaRow: {flexDirection: 'row-reverse', gap: 10, marginTop: 4},
  meta: {fontSize: 11, color: colors.sub, fontWeight: '600'},
  count: {alignItems: 'center', justifyContent: 'center', backgroundColor: colors.dangerSoft,
    borderRadius: 10, paddingHorizontal: 10, paddingVertical: 4},
  countTxt: {fontSize: 18, fontWeight: '900', color: colors.danger},
  countLbl: {fontSize: 9, color: colors.danger, fontWeight: '700'},
});