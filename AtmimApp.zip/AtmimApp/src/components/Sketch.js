import React, {useRef, useState} from 'react';
import {View, PanResponder, StyleSheet} from 'react-native';
import Svg, {Polyline} from 'react-native-svg';

export const pts2str = pts => pts.map(p => `${p.x},${p.y}`).join(' ');

export default function Sketch({paths, onChange, color = '#E5484D', stroke = 3, style}) {
  const [cur, setCur] = useState(null);
  const curRef = useRef(null);

  const pr = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: e => {
        const p = {x: e.nativeEvent.locationX, y: e.nativeEvent.locationY};
        curRef.current = [p];
        setCur([p]);
      },
      onPanResponderMove: e => {
        const p = {x: e.nativeEvent.locationX, y: e.nativeEvent.locationY};
        curRef.current = [...(curRef.current || []), p];
        setCur(curRef.current);
      },
      onPanResponderRelease: () => {
        if (curRef.current?.length > 1) onChange([...paths, {pts: curRef.current, color}]);
        curRef.current = null;
        setCur(null);
      },
    }),
  ).current;

  return (
    <View style={[st.c, style]} {...pr.panHandlers}>
      <Svg style={StyleSheet.absoluteFill} pointerEvents="none">
        {paths.map((p, i) => (
          <Polyline key={i} points={pts2str(p.pts)} stroke={p.color} strokeWidth={stroke}
            fill="none" strokeLinecap="round" strokeLinejoin="round" />
        ))}
        {cur && <Polyline points={pts2str(cur)} stroke={color} strokeWidth={stroke}
          fill="none" strokeLinecap="round" strokeLinejoin="round" />}
      </Svg>
    </View>
  );
}

const st = StyleSheet.create({c: {flex: 1}});