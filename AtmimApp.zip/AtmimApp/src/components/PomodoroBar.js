import React, {useEffect, useState} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import {colors} from '../theme/theme';
import {fmtRemain} from '../utils/helpers';

// خط تحت المهمة، نقطة تتحرك من اليمين لليسار + رقم الوقت فوقها
export default function PomodoroBar({totalMinutes, startedAt, onEnd}) {
  const total = totalMinutes * 60000;
  const [remain, setRemain] = useState(total - (Date.now() - startedAt));

  useEffect(() => {
    const iv = setInterval(() => {
      const r = total - (Date.now() - startedAt);
      setRemain(r);
      if (r <= 0) {
        clearInterval(iv);
        onEnd && onEnd();
      }
    }, 1000);
    return () => clearInterval(iv);
  }, []);

  const progress = Math.max(0, Math.min(1, remain / total)); // 1 → 0
  return (
    <View style={st.wrap}>
      <Text style={st.time}>{fmtRemain(remain)}</Text>
      <View style={st.track}>
        <View style={[st.fill, {width: `${progress * 100}%`}]} />
        <View style={[st.dot, {right: `${(1 - progress) * 100}%`}]} />
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  wrap: {marginTop: 8},
  time: {fontSize: 12, fontWeight: '800', color: colors.primary, marginBottom: 4, textAlign: 'left'},
  track: {height: 4, borderRadius: 2, backgroundColor: colors.border, justifyContent: 'center'},
  fill: {position: 'absolute', right: 0, height: 4, borderRadius: 2, backgroundColor: colors.primarySoft},
  dot: {position: 'absolute', width: 10, height: 10, borderRadius: 5, backgroundColor: colors.primary, marginRight: -5},
});