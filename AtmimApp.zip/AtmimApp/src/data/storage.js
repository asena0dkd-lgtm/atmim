import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = '@atmim_v1';

export const loadAll = async () => {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
};

export const saveAll = async data => {
  try {
    await AsyncStorage.setItem(KEY, JSON.stringify(data));
  } catch (e) {}
};