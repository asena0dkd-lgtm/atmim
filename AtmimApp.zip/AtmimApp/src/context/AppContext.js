import React, {createContext, useContext, useEffect, useState} from 'react';
import {Alert} from 'react-native';
import {loadAll, saveAll} from '../data/storage';
import {uid} from '../utils/helpers';

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

export const DEFAULT_CHEERS = [
  'ممتاز! أنجزت «{task}» — اصبر شوي ورح توصل لهدفك 💪',
  'رائع! «{task}» تمّت بنجاح. الانضباط يصنع المعجزات 🏆',
  'أحسنت! خطوة أخرى نحو نسخة أقوى منك ✅',
];
export const DEFAULT_TAUNTS = [
  'ما أنجزت «{task}»؟ الخطة ما بتمشي لحالها… قوم الآن ⏰',
  '«{task}» لسا بتستناك. التأجيل عدوّك 😤',
];

const fill = (msg, t) => (msg || '').replaceAll('{task}', t.title);
const pick = arr => arr[Math.floor(Math.random() * arr.length)];

export const nextOccurrence = t => {
  const d = new Date();
  switch (t.repeat) {
    case 'daily': d.setDate(d.getDate() + 1); break;
    case 'weekly': d.setDate(d.getDate() + 7); break;
    case 'monthly': d.setMonth(d.getMonth() + 1); break;
    case 'yearly': d.setFullYear(d.getFullYear() + 1); break;
    case 'custom': d.setDate(d.getDate() + (t.customDays || 1)); break;
    default: return null;
  }
  if (t.scheduledAt) {
    const s = new Date(t.scheduledAt);
    d.setHours(s.getHours(), s.getMinutes(), 0, 0);
  }
  return d.getTime();
};

export function AppProvider({children}) {
  const [ready, setReady] = useState(false);
  const [tasks, setTasks] = useState([]);
  const [notes, setNotes] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [cheers, setCheers] = useState(DEFAULT_CHEERS);
  const [taunts, setTaunts] = useState(DEFAULT_TAUNTS);

  useEffect(() => {
    (async () => {
      const d = await loadAll();
      if (d) {
        setTasks(d.tasks || []); setNotes(d.notes || []); setRooms(d.rooms || []);
        if (d.cheers?.length) setCheers(d.cheers);
        if (d.taunts?.length) setTaunts(d.taunts);
      }
      setReady(true);
    })();
  }, []);

  useEffect(() => {
    if (ready) saveAll({tasks, notes, rooms, cheers, taunts});
  }, [tasks, notes, rooms, cheers, taunts, ready]);

  // كشف المهام المرتبطة عند حدث معيّن
  const revealLinked = (src, ev, list) =>
    list.map(t => {
      const link = (src.linked || []).find(
        l => l.taskId === t.id && l.on === ev &&
          (!l.afterFails || (src.failCount || 0) + (ev === 'fail' ? 1 : 0) >= l.afterFails),
      );
      if (link && t.hidden) {
        Alert.alert('🔗 مهمة مرتبطة', `ظهرت المهمة «${t.title}» الآن في قائمتك`);
        return {...t, hidden: false};
      }
      return t;
    });

  // ---------- المهام ----------
  const addTask = data =>
    setTasks(ts => [{id: uid(), createdAt: Date.now(), status: 'active', failCount: 0,
      repeat: 'none', linked: [], attachments: [], checklist: [], hidden: false, ...data}, ...ts]);

  const updateTask = (id, patch) =>
    setTasks(ts => ts.map(t => (t.id === id ? {...t, ...patch} : t)));

  const deleteTask = id => setTasks(ts => ts.filter(t => t.id !== id));

  const completeTask = id => {
    const t = tasks.find(x => x.id === id);
    if (!t) return;
    Alert.alert('🎉 أحسنت!', fill(t.cheer || pick(cheers), t));
    let out = revealLinked(t, 'done', tasks);
    out = out.map(x => {
      if (x.id !== id) return x;
      if (x.repeat && x.repeat !== 'none') {
        return {...x, status: 'active', failCount: 0,
          scheduledAt: nextOccurrence(x), pomodoroStartedAt: null};
      }
      return {...x, status: 'done', completedAt: Date.now()};
    });
    setTasks(out);
  };

  const failTask = id => {
    const t = tasks.find(x => x.id === id);
    if (!t) return;
    Alert.alert('😤 للأسف', fill(t.taunt || pick(taunts), t));
    let out = revealLinked(t, 'fail', tasks);
    out = out.map(x => {
      if (x.id !== id) return x;
      const fc = (x.failCount || 0) + 1;
      if (x.repeat && x.repeat !== 'none') {
        return {...x, failCount: fc, status: 'active',
          scheduledAt: nextOccurrence(x), pomodoroStartedAt: null};
      }
      return {...x, failCount: fc, status: 'failed'};
    });
    setTasks(out);
  };

  const cancelTask = id => {
    const t = tasks.find(x => x.id === id);
    if (!t) return;
    let out = revealLinked(t, 'cancel', tasks);
    out = out.map(x => (x.id === id ? {...x, status: 'cancelled'} : x));
    setTasks(out);
  };

  // تشغيل مؤقّت البومودو تلقائيًا عند حلول وقت المهمة + إشعار
  const startPomodoroIfDue = () => {
    const due = tasks.filter(t =>
      t.status === 'active' && !t.hidden && t.scheduledAt && t.pomodoro &&
      !t.pomodoroStartedAt && Date.now() >= t.scheduledAt);
    if (due.length) {
      due.forEach(t =>
        Alert.alert('⏰ حان وقت المهمة', `${t.title}\nمدة المؤقت: ${t.pomodoro} دقيقة`));
      const ids = due.map(t => t.id);
      setTasks(ts => ts.map(x =>
        ids.includes(x.id) ? {...x, pomodoroStartedAt: Date.now()} : x));
    }
  };

  // ---------- الملاحظات ----------
  const addNote = data => {
    const n = {id: uid(), createdAt: Date.now(), title: 'ملاحظة جديدة',
      blocks: [{id: uid(), type: 'line', text: ''}], snippets: [], drawings: [],
      waypoint: null, ...data};
    setNotes(ns => [n, ...ns]);
    return n.id;
  };
  const updateNote = (id, patch) =>
    setNotes(ns => ns.map(n => (n.id === id ? {...n, ...patch} : n)));
  const deleteNote = id => setNotes(ns => ns.filter(n => n.id !== id));

  // ---------- الغرف ----------
  const addRoom = data => {
    const r = {id: uid(), createdAt: Date.now(), name: 'غرفة جديدة',
      bgColor: '#FFFFFF', bgType: 'grid', elements: [], drawings: [], ...data};
    setRooms(rs => [r, ...rs]);
    return r.id;
  };
  const updateRoom = (id, patch) =>
    setRooms(rs => rs.map(r => (r.id === id ? {...r, ...patch} : r)));
  const deleteRoom = id => setRooms(rs => rs.filter(r => r.id !== id));

  return (
    <Ctx.Provider value={{
      ready, tasks, notes, rooms, cheers, taunts, setCheers, setTaunts,
      addTask, updateTask, deleteTask, completeTask, failTask, cancelTask,
      startPomodoroIfDue, addNote, updateNote, deleteNote,
      addRoom, updateRoom, deleteRoom,
    }}>
      {children}
    </Ctx.Provider>
  );
}