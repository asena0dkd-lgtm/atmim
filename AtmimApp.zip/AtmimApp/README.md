# ✅ أتمم — مهام · ملاحظات · غرف

تطبيق React Native (أندرويد) بالعربية RTL كامل.

## التشغيل

```bash
# 1) أنشئ الهيكل الأصلي (يولّد مجلد android/)
npx @react-native-community/cli@latest init AtmimApp --version 0.74.5

# 2) انسخ ملفات هذا المشروع فوق المشروع المُنشأ (استبدل الملفات)

# 3) ثبّت الحزم
cd AtmimApp
npm install

# 4) شغّل
npx react-native run-android
```

> بعد التفعيل الأول لـ RTL قد تحتاج إعادة تشغيل التطبيق مرة واحدة.

## أذونات AndroidManifest.xml (أضف داخل <manifest>)
```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
<uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
<uses-permission android:name="android.permission.VIBRATE"/>
```

## قفل الاتجاه الأفقي للغرف (react-native-orientation-locker)
أضف في `MainActivity.java`:
```java
import android.content.Intent;
import android.content.res.Configuration;

@Override
public void onConfigurationChanged(Configuration newConfig) {
  super.onConfigurationChanged(newConfig);
  Intent intent = new Intent("onConfigurationChanged");
  intent.putExtra("newConfig", newConfig);
  sendBroadcast(intent);
}
```

## ملاحظات
- الإشعارات تعمل داخل التطبيق (أثناء فتحه). للإشعارات في الخلفية أضف `notifee`.
- التصدير (MD/HTML/صورة الغرفة) يتم عبر نافذة المشاركة — يمكن حفظه كملف منها.